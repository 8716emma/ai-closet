
## [Calculator] Completed
- 풀오토 시뮬레이션 성공
