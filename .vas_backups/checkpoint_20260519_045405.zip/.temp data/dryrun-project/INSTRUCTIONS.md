# Pomodoro Timer Instructions
- 500 lines limit
- Vanilla HTML/JS
