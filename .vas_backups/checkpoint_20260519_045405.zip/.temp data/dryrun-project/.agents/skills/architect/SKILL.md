# Architect Agent
Role: Mock architect
