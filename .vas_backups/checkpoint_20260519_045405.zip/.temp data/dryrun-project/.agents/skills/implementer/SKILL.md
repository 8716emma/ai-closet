# Implementer Agent
Role: Mock implementer
