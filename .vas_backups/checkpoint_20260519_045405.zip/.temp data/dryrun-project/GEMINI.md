# Pomodoro Timer - AI Context
- Purpose: Focus Tool
- Stack: HTML/JS/CSS
