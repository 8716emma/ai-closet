/**
 * slide-styles-data.js
 * NotebookLM 슬라이드 스타일 데이터 — 300가지 템플릿
 *
 * 자동 생성: Recommended Graphics.html 에서 추출
 */

const TEMPLATES = [
  // ========== 심플 (8) ==========
  { id: 'minimal', name: '미니멀 젠', category: '심플', style: { bg: '#FFFFFF', text: '#000000', accent: '#9ca3af', font: 'Helvetica Neue' },
    mood: 'Apple 키노트, 무인양품(MUJI)', characteristics: ['여백 60% 이상', '요소 3개 이하', '무채색 기반', '얇은 산세리프'], texture: '없음 (순수 평면)', layoutGuide: '제목 정중앙, 위아래 얇은 구분선' },
  
  { id: 'monochrome', name: '블랙 & 화이트', category: '심플', style: { bg: '#000000', text: '#ffffff', accent: '#ffffff', font: 'DM Sans' },
    mood: 'Karl Lagerfeld, 갤러리 도록', characteristics: ['순수 흑백', '강한 명암 대비', '대담한 타이포', '네거티브 스페이스'], texture: '미세 노이즈 5%', layoutGuide: '검정 배경 + 흰색 대문자, Bold 처리' },
  
  { id: 'nordic', name: '노르딕', category: '심플', style: { bg: '#F0F4F8', text: '#2d3748', accent: '#718096', font: 'Inter' },
    mood: 'IKEA, 코펜하겐 인테리어', characteristics: ['파스텔 뮤트 톤', '둥근 모서리 8px', '자연광 느낌', '따뜻한 기능미'], texture: '린넨 텍스처 3%', layoutGuide: '좌측 정렬, 우상단 원형 장식' },
  
  { id: 'wireframe', name: '와이어프레임', category: '심플', style: { bg: '#1a202c', text: '#e2e8f0', accent: '#4299e1', font: 'Roboto Mono' },
    mood: 'Figma 목업, UI 설계서', characteristics: ['점선 테두리', '플레이스홀더 박스', '모노스페이스', '청사진 그리드'], texture: '도트 그리드 20px', layoutGuide: '점선 프레임, [TITLE] 스타일' },
  
  { id: 'paper', name: '화이트 페이퍼', category: '심플', style: { bg: '#FAFAFA', text: '#374151', accent: '#6B7280', font: 'Georgia' },
    mood: '학술 백서, 공식 문서', characteristics: ['깔끔한 여백', '세리프 본문', '미니멀 장식', '인쇄물 느낌'], texture: '종이 질감 2%', layoutGuide: '상단 제목, 하단 페이지 번호 스타일' },
  
  { id: 'muji', name: '무인양품', category: '심플', style: { bg: '#F5F5F0', text: '#4A4A4A', accent: '#8B7355', font: 'Noto Sans KR' },
    mood: 'MUJI 카탈로그, 생활용품', characteristics: ['자연스러운 베이지', '군더더기 없음', '기능 중심', '차분한 톤'], texture: '크래프트 종이 hint', layoutGuide: '중앙 정렬, 최소한의 요소' },
  
  { id: 'zen', name: '젠 가든', category: '심플', style: { bg: '#F7F6F3', text: '#2C2C2C', accent: '#7C8B6F', font: 'Cormorant' },
    mood: '일본 정원, 다도 문화', characteristics: ['비대칭 균형', '자연 모티프', '고요한 분위기', '세리프 우아함'], texture: '와시 종이 느낌', layoutGuide: '좌측 여백 크게, 우측에 제목' },
  
  { id: 'clean', name: '클린 모던', category: '심플', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#3B82F6', font: 'SF Pro Display' },
    mood: 'iOS 인터페이스, 테크 기업', characteristics: ['시스템 폰트', '파란 포인트', '카드 UI', '그림자 활용'], texture: '없음', layoutGuide: '카드 형태 중앙 배치' },

  // ========== 모던 (10) ==========
  { id: 'cyberpunk', name: '네온 퓨처', category: '모던', style: { bg: '#050505', text: '#00ff9d', accent: '#ff00ff', font: 'Roboto Mono' },
    mood: 'Blade Runner, CD Projekt', characteristics: ['네온 글로우', '어둠+형광', '글리치 효과', 'HUD 스타일'], texture: '스캔라인 2px', layoutGuide: '네온 글로우 blur 20px, 사이버 프레임' },
  
  { id: 'swiss', name: '스위스 스타일', category: '모던', style: { bg: '#ffffff', text: '#1a1a1a', accent: '#e11d48', font: 'Helvetica' },
    mood: 'Helvetica 다큐, 국제 양식', characteristics: ['엄격한 그리드', '산세리프', '빨강/검정/흰색', '비대칭 균형'], texture: '없음', layoutGuide: '좌측 빨간 사각형, 그리드 라인 10%' },
  
  { id: 'glass', name: '글래스모피즘', category: '모던', style: { bg: '#E8EEF5', text: '#334155', accent: '#38bdf8', font: 'Inter' },
    mood: 'iOS Big Sur, Windows 11', characteristics: ['반투명 blur 20px', '밝은 테두리', '그림자 레이어링', '그라데이션 배경'], texture: '프로스티드 글래스', layoutGuide: '중앙 글래스 카드, 그라데이션 메쉬 배경' },
  
  { id: 'neon', name: '네온 느와르', category: '모던', style: { bg: '#0f0f0f', text: '#f43f5e', accent: '#8b5cf6', font: 'Space Grotesk' },
    mood: '홍콩 네온, 느와르 영화', characteristics: ['near black 배경', '핑크/퍼플/시안', '글로우 15px', '빈티지 무드'], texture: '도시 노이즈', layoutGuide: '더블 글로우, 하단 반사 효과' },
  
  { id: 'bauhaus', name: '바우하우스', category: '모던', style: { bg: '#f4f4f5', text: '#111', accent: '#eab308', font: 'Futura' },
    mood: 'Bauhaus 포스터, 몬드리안', characteristics: ['원/삼각/사각', '빨강/노랑/파랑', '굵은 검정선', '기하학 구성'], texture: '없음', layoutGuide: '좌상단 빨간원, 우측 노란사각, 하단 파란바' },
  
  { id: 'gradient', name: '오로라 그라데이션', category: '모던', style: { bg: '#0F0F1A', text: '#FFFFFF', accent: '#A855F7', font: 'Outfit' },
    mood: 'Stripe, Linear 웹사이트', characteristics: ['메쉬 그라데이션', '퍼플-블루-핑크', '부드러운 전환', '미래적 느낌'], texture: '메쉬 그라데이션', layoutGuide: '배경 전체 그라데이션, 흰색 텍스트' },
  
  { id: 'brutalism', name: '웹 브루탈리즘', category: '모던', style: { bg: '#FFFF00', text: '#000000', accent: '#FF0000', font: 'Times New Roman' },
    mood: 'Bloomberg, 실험적 웹', characteristics: ['극단적 대비', '기본 폰트', '의도적 불편함', '원색 충돌'], texture: '없음', layoutGuide: '노란 배경에 검정 텍스트, 빨간 밑줄' },
  
  { id: 'neumorphism', name: '뉴모피즘', category: '모던', style: { bg: '#E0E5EC', text: '#2D3748', accent: '#4299E1', font: 'Poppins' },
    mood: '소프트 UI, 3D 버튼', characteristics: ['볼록/오목 효과', '동일 배경색', '부드러운 그림자', '촉각적 느낌'], texture: '없음', layoutGuide: '볼록한 카드 효과, 부드러운 그림자' },
  
  { id: 'dark', name: '다크 모드', category: '모던', style: { bg: '#18181B', text: '#FAFAFA', accent: '#22D3EE', font: 'Inter' },
    mood: 'GitHub Dark, VS Code', characteristics: ['다크 그레이 배경', '밝은 텍스트', '시안 강조', '눈 편안함'], texture: '없음', layoutGuide: '어두운 카드, 시안 포인트' },
  
  { id: 'memphis', name: '멤피스', category: '모던', style: { bg: '#FFE4E1', text: '#1A1A2E', accent: '#FF6B6B', font: 'Quicksand' },
    mood: '80s 멤피스 디자인, 포스트모던', characteristics: ['기하학 패턴', '파스텔+원색', '물결/점/지그재그', '장난스러움'], texture: '기하학 패턴', layoutGuide: '배경에 도형 패턴, 중앙 제목' },

  // ========== 비즈니스 (10) ==========
  { id: 'corporate', name: '코퍼레이트', category: '비즈니스', style: { bg: '#ffffff', text: '#0f172a', accent: '#0ea5e9', font: 'Inter' },
    mood: 'McKinsey, LinkedIn', characteristics: ['깔끔한 차트', '파란색 신뢰감', '명확한 계층', '프로 사진'], texture: '없음', layoutGuide: '상단 컬러바, 중앙 제목, 하단 날짜' },
  
  { id: 'startup', name: '스타트업 피치', category: '비즈니스', style: { bg: '#fff', text: '#111', accent: '#6366F1', font: 'Pretendard' },
    mood: 'Y Combinator, Airbnb 초기', characteristics: ['임팩트 숫자', '심플 아이콘', '에너지 컬러', '스토리텔링'], texture: '없음', layoutGuide: '"We are changing X" 한 문장 강조' },
  
  { id: 'finance', name: '파이낸스', category: '비즈니스', style: { bg: '#064e3b', text: '#ecfdf5', accent: '#34d399', font: 'Lato' },
    mood: 'Bloomberg Terminal, 투자은행', characteristics: ['어두운 녹색/검정', '형광 녹색', '데이터 테이블', '차트 중심'], texture: '미세 그리드', layoutGuide: '좌측 세로바, 대문자 제목' },
  
  { id: 'medical', name: '메디컬 케어', category: '비즈니스', style: { bg: '#f0f9ff', text: '#0c4a6e', accent: '#0284c7', font: 'Nunito Sans' },
    mood: 'WHO, Johns Hopkins', characteristics: ['청결 흰색/하늘색', '의료 아이콘', '신뢰 레이아웃', '명확한 데이터'], texture: '없음', layoutGuide: '상단 로고, 중앙 제목, + 심볼' },
  
  { id: 'realestate', name: '럭셔리 부동산', category: '비즈니스', style: { bg: '#1C1C1C', text: '#FFFFFF', accent: '#C9A962', font: 'Cormorant' },
    mood: '고급 부동산, 건축 잡지', characteristics: ['넓은 사진', '골드 포인트', '미니멀 텍스트', '여백의 미'], texture: '대리석 hint', layoutGuide: '전체 이미지, 하단 골드 바' },
  
  { id: 'legal', name: '법률 문서', category: '비즈니스', style: { bg: '#FFFEF5', text: '#1F2937', accent: '#7C3AED', font: 'Garamond' },
    mood: '로펌, 공식 계약서', characteristics: ['전통 세리프', '보수적 레이아웃', '권위적 컬러', '정돈된 여백'], texture: '양피지 hint', layoutGuide: '중앙 정렬, 상단 로고, 하단 날인' },
  
  { id: 'consulting', name: '컨설팅 리포트', category: '비즈니스', style: { bg: '#1E3A5F', text: '#FFFFFF', accent: '#00B4D8', font: 'Roboto' },
    mood: 'BCG, Deloitte 보고서', characteristics: ['네이비 배경', '시안 강조', '데이터 시각화', '매트릭스 레이아웃'], texture: '없음', layoutGuide: '좌측 로고, 우측 제목, 하단 차트' },
  
  { id: 'tech', name: '테크 기업', category: '비즈니스', style: { bg: '#0A0A0A', text: '#FFFFFF', accent: '#00D084', font: 'SF Pro Display' },
    mood: 'Apple 발표, Google I/O', characteristics: ['다크 배경', '그린 포인트', '대형 타이포', '제품 중심'], texture: '없음', layoutGuide: '중앙 대형 텍스트, 하단 부제' },
  
  { id: 'hr', name: 'HR/채용', category: '비즈니스', style: { bg: '#FDF4FF', text: '#581C87', accent: '#A855F7', font: 'Plus Jakarta Sans' },
    mood: '채용 브로셔, 회사 소개', characteristics: ['따뜻한 퍼플', '사람 중심', '친근한 무드', '아이콘 활용'], texture: '없음', layoutGuide: '팀 사진 영역, 컬러풀 강조' },
  
  { id: 'retail', name: '리테일/커머스', category: '비즈니스', style: { bg: '#FFFFFF', text: '#111827', accent: '#EF4444', font: 'DM Sans' },
    mood: 'Supreme, 패션 브랜드', characteristics: ['빨간 강조', '볼드 타이포', '제품 포커스', '그리드 레이아웃'], texture: '없음', layoutGuide: '빨간 박스 로고, 큰 제품 이미지' },

  // ========== 내추럴 (8) ==========
  { id: 'forest', name: '포레스트', category: '내추럴', style: { bg: '#fcf9ee', text: '#2c3e2e', accent: '#567c5d', font: 'Merriweather' },
    mood: 'National Geographic, 환경 다큐', characteristics: ['자연 녹색/갈색', '유기적 곡선', '손글씨 믹스', '에코 무드'], texture: '나뭇잎 패턴 subtle', layoutGuide: '자연 일러스트 프레임, 중앙 제목' },
  
  { id: 'space', name: '딥 스페이스', category: '내추럴', style: { bg: '#020617', text: '#e2e8f0', accent: '#6366f1', font: 'Orbitron' },
    mood: 'NASA, Interstellar', characteristics: ['우주 검정/남색', '별/은하', '미래적 폰트', '빛나는 포인트'], texture: '별 필드', layoutGuide: '별 배경, 제목 글로우, 행성 장식' },
  
  { id: 'ocean', name: '딥 오션', category: '내추럴', style: { bg: '#0c4a6e', text: '#e0f2fe', accent: '#38bdf8', font: 'Montserrat' },
    mood: 'Blue Planet, 해양 캠페인', characteristics: ['깊은 파랑 그라데이션', '물결 패턴', '투명감', '수중 느낌'], texture: 'caustics 효과', layoutGuide: '상단→하단 그라데이션, 파도 라인' },
  
  { id: 'desert', name: '사하라 듄', category: '내추럴', style: { bg: '#fff7ed', text: '#7c2d12', accent: '#ea580c', font: 'Lora' },
    mood: 'Dune 영화, 사막 다큐', characteristics: ['오렌지/베이지', '모래 언덕 곡선', '강한 햇빛', '황금 그라데이션'], texture: '모래 노이즈', layoutGuide: '하단 언덕 실루엣, 상단 태양' },
  
  { id: 'aurora', name: '오로라', category: '내추럴', style: { bg: '#0F172A', text: '#F0FDF4', accent: '#4ADE80', font: 'Nunito' },
    mood: '북유럽 오로라, 겨울밤', characteristics: ['그린-퍼플 오로라', '어두운 밤하늘', '신비로운 빛', '자연 현상'], texture: '오로라 그라데이션', layoutGuide: '상단 오로라 효과, 하단 실루엣' },
  
  { id: 'botanical', name: '보타니컬', category: '내추럴', style: { bg: '#FEFCE8', text: '#365314', accent: '#84CC16', font: 'Playfair Display' },
    mood: '식물도감, 보태니컬 아트', characteristics: ['식물 일러스트', '빈티지 그린', '세밀한 디테일', '과학적 레이아웃'], texture: '오래된 종이', layoutGuide: '중앙 식물 일러스트, 라벨 스타일' },
  
  { id: 'mountain', name: '알파인', category: '내추럴', style: { bg: '#F1F5F9', text: '#0F172A', accent: '#0369A1', font: 'Montserrat' },
    mood: '파타고니아, 등산 브랜드', characteristics: ['산 실루엣', '블루 그레이', '아웃도어 무드', '미니멀 자연'], texture: '없음', layoutGuide: '하단 산 실루엣, 상단 대형 텍스트' },
  
  { id: 'tropical', name: '트로피컬', category: '내추럴', style: { bg: '#ECFDF5', text: '#064E3B', accent: '#F59E0B', font: 'Varela Round' },
    mood: '하와이, 열대 리조트', characteristics: ['야자수 패턴', '밝은 그린', '옐로우 포인트', '휴양지 무드'], texture: '열대 잎 패턴', layoutGuide: '모서리 야자수 장식, 중앙 제목' },

  // ========== 럭셔리 (6) ==========
  { id: 'luxury', name: '골든 아워', category: '럭셔리', style: { bg: '#1c1917', text: '#fafaf9', accent: '#d4af37', font: 'Playfair Display' },
    mood: 'Rolex, Louis Vuitton', characteristics: ['골드/블랙', '세리프 폰트', '얇은 골드 라인', '대칭 구성'], texture: '미세 노이즈', layoutGuide: '중앙 대칭, 위아래 골드 라인' },
  
  { id: 'editorial', name: '보그 에디토리얼', category: '럭셔리', style: { bg: '#f9fafb', text: '#18181b', accent: '#dc2626', font: 'Bodoni Moda' },
    mood: 'Vogue, Harper\'s Bazaar', characteristics: ['대담한 타이포', '흑백+원포인트', '매거진 그리드', '사진 오버랩'], texture: '없음', layoutGuide: '대형 세리프 제목, 빨간 강조 점' },
  
  { id: 'jewelry', name: '다이아몬드', category: '럭셔리', style: { bg: '#1E1B4B', text: '#E0E7FF', accent: '#C084FC', font: 'Cinzel' },
    mood: 'Tiffany, Cartier', characteristics: ['딥 퍼플/네이비', '보석 반짝임', '섬세한 디테일', '곡선 우아함'], texture: '벨벳+스파클', layoutGuide: '다이아몬드 프레임, 미세 파티클' },
  
  { id: 'champagne', name: '샴페인 골드', category: '럭셔리', style: { bg: '#FFFBEB', text: '#78350F', accent: '#D97706', font: 'Cormorant Garamond' },
    mood: '웨딩, 셀러브레이션', characteristics: ['샴페인 골드', '우아한 서체', '버블 효과', '축하 무드'], texture: '미세 버블', layoutGuide: '아치 프레임, 골드 버블 장식' },
  
  { id: 'noir', name: '누아르', category: '럭셔리', style: { bg: '#000000', text: '#D4D4D8', accent: '#A1A1AA', font: 'Bebas Neue' },
    mood: '고급 향수, 아트 하우스', characteristics: ['완전한 블랙', '실버 톤', '미스터리', '극적 조명'], texture: '필름 그레인', layoutGuide: '어둠 속 텍스트, 스팟 조명 효과' },
  
  { id: 'marble', name: '이탈리안 마블', category: '럭셔리', style: { bg: '#F5F5F5', text: '#1F2937', accent: '#9CA3AF', font: 'Libre Baskerville' },
    mood: '럭셔리 호텔, 건축 명품', characteristics: ['대리석 텍스처', '그레이 톤', '클래식 세리프', '고급 소재감'], texture: '마블 패턴', layoutGuide: '마블 배경, 심플 중앙 텍스트' },

  // ========== 레트로 (12) ==========
  { id: 'synthwave', name: '신스웨이브', category: '레트로', style: { bg: '#2e1065', text: '#f0abfc', accent: '#22d3ee', font: 'Righteous' },
    mood: 'Miami Vice, Stranger Things', characteristics: ['네온 핑크/시안', '선셋 그라데이션', '크롬 텍스트', '야자수/그리드'], texture: 'VHS 노이즈', layoutGuide: '하단 그리드, 크롬 제목, 태양 실루엣' },
  
  { id: 'pixel', name: '8비트 아케이드', category: '레트로', style: { bg: '#18181b', text: '#4ade80', accent: '#fb7185', font: 'Press Start 2P' },
    mood: '슈퍼마리오, 아케이드', characteristics: ['픽셀 폰트', '제한된 팔레트', '도트 그래픽', '게임 UI'], texture: '픽셀 그리드', layoutGuide: '"PRESS START", 스코어바, 픽셀 프레임' },
  
  { id: 'y2k', name: 'Y2K 퓨처', category: '레트로', style: { bg: '#e0e7ff', text: '#4338ca', accent: '#ec4899', font: 'Orbitron' },
    mood: '2000년대 초, 초기 아이맥', characteristics: ['투명 플라스틱', '파스텔+메탈릭', '버블/별', '3D 광택'], texture: '글로시 그라데이션', layoutGuide: '광택 타이틀, 별/하트 장식' },
  
  { id: 'polaroid', name: '폴라로이드', category: '레트로', style: { bg: '#FFFEF5', text: '#44403C', accent: '#78716C', font: 'Caveat' },
    mood: '인스탁스, 빈티지 앨범', characteristics: ['흰색 프레임', '바랜 색감', '손글씨 캡션', '필름 느낌'], texture: '종이+세피아', layoutGuide: '폴라로이드 프레임, 하단 손글씨' },
  
  { id: 'vinyl', name: '재즈 바이닐', category: '레트로', style: { bg: '#1C1917', text: '#FCA5A5', accent: '#F87171', font: 'Abril Fatface' },
    mood: 'Blue Note, 70s 레코드', characteristics: ['따뜻한 아날로그', '레코드 원형', '빈티지 타이포', '노이즈/그레인'], texture: '비닐 그루브', layoutGuide: '레코드판 그래픽, 빈티지 서체' },
  
  { id: 'brutalist', name: '브루탈 콘크리트', category: '레트로', style: { bg: '#d1d5db', text: '#000', accent: '#525252', font: 'Archivo Black' },
    mood: '콘크리트 건축, Raw HTML', characteristics: ['무거운 블록', '고대비 흑백', '거친 텍스처', '투박함'], texture: '콘크리트 노이즈', layoutGuide: '검정 블록 제목, 거친 회색 배경' },
  
  { id: 'vhs', name: 'VHS 글리치', category: '레트로', style: { bg: '#0D0D0D', text: '#FFFFFF', accent: '#FF00FF', font: 'VCR OSD Mono' },
    mood: 'VHS 테이프, 글리치 아트', characteristics: ['RGB 분리', '스캔라인', '노이즈 왜곡', 'TV 에러'], texture: 'VHS 스캔라인', layoutGuide: 'RGB 분리 텍스트, 트래킹 에러' },
  
  { id: 'disco', name: '디스코 70s', category: '레트로', style: { bg: '#4A1942', text: '#FFD700', accent: '#FF69B4', font: 'Pacifico' },
    mood: '디스코 클럽, Saturday Night Fever', characteristics: ['미러볼 반짝임', '골드/핑크', '그루비 폰트', '댄스 무드'], texture: '글리터 효과', layoutGuide: '미러볼 요소, 골드 제목' },
  
  { id: 'newspaper', name: '빈티지 신문', category: '레트로', style: { bg: '#F5F5DC', text: '#1A1A1A', accent: '#8B0000', font: 'Playfair Display' },
    mood: '1920s 신문, 헤드라인', characteristics: ['세리프 헤드라인', '컬럼 레이아웃', '세피아 톤', '빨간 강조'], texture: '오래된 신문지', layoutGuide: '큰 헤드라인, 컬럼 구분선' },
  
  { id: 'psychedelic', name: '사이키델릭', category: '레트로', style: { bg: '#FF6B35', text: '#1A1A2E', accent: '#FFE66D', font: 'Rubik Mono One' },
    mood: '60s 히피, 우드스톡', characteristics: ['물결치는 패턴', '강렬한 원색', '환각적 무드', '유기적 형태'], texture: '물결 패턴', layoutGuide: '물결치는 텍스트, 소용돌이 배경' },
  
  { id: 'art_deco', name: '아르데코', category: '레트로', style: { bg: '#1A1A2E', text: '#D4AF37', accent: '#C9A962', font: 'Poiret One' },
    mood: '1920s 뉴욕, 개츠비', characteristics: ['기하학 패턴', '골드 라인', '대칭 구조', '럭셔리 빈티지'], texture: '기하학 패턴', layoutGuide: '아르데코 프레임, 골드 라인 장식' },
  
  { id: 'polaroid_grid', name: '폴라로이드 콜라주', category: '레트로', style: { bg: '#3D3D3D', text: '#FFFFFF', accent: '#F5F5F5', font: 'Indie Flower' },
    mood: '추억 사진첩, 콜라주', characteristics: ['여러 프레임 겹침', '테이프 장식', '손글씨 라벨', '비정형 배치'], texture: '코르크 보드', layoutGuide: '겹친 폴라로이드들, 테이프 효과' },

  // ========== 크리에이티브 (10) ==========
  { id: 'gallery', name: '모던 갤러리', category: '크리에이티브', style: { bg: '#f3f4f6', text: '#111827', accent: '#ec4899', font: 'Abril Fatface' },
    mood: 'MoMA, 현대미술관', characteristics: ['여백과 오브제', '아티스틱 폰트', '비대칭 레이아웃', '컬러 팝'], texture: '캔버스 subtle', layoutGuide: '컬러 원형+타이틀 오버랩' },
  
  { id: 'vivid', name: '비비드 팝', category: '크리에이티브', style: { bg: '#facc15', text: '#000000', accent: '#2563eb', font: 'Poppins' },
    mood: 'Andy Warhol, Keith Haring', characteristics: ['원색 대비', '굵은 아웃라인', '에너지 폭발', '반복 패턴'], texture: '하프톤 도트', layoutGuide: '노란 배경, 파란 원, 팝아트 스타일' },
  
  { id: 'graffiti', name: '스트릿 그래피티', category: '크리에이티브', style: { bg: '#111', text: '#facc15', accent: '#ec4899', font: 'Permanent Marker' },
    mood: 'Banksy, 뉴욕 스트릿', characteristics: ['스프레이 효과', '거친 텍스처', '스텐실', '반항적 에너지'], texture: '벽돌 벽', layoutGuide: '스프레이 제목, 드립 효과' },
  
  { id: 'collage', name: '다다 콜라주', category: '크리에이티브', style: { bg: '#fef3c7', text: '#78350f', accent: '#d97706', font: 'Courier Prime' },
    mood: '다다이즘, 잡지 콜라주', characteristics: ['오려붙인 종이', '폰트 믹스', '테이프/스티커', '레이어 겹침'], texture: '찢어진 종이', layoutGuide: '겹친 종이 조각, 잡지 스타일' },
  
  { id: 'watercolor', name: '수채화', category: '크리에이티브', style: { bg: '#FFFBF5', text: '#4A4A4A', accent: '#7C9EB2', font: 'Dancing Script' },
    mood: '수채화 아트, 손그림 일러스트', characteristics: ['번지는 효과', '파스텔 물감', '손글씨 폰트', '부드러운 경계'], texture: '수채화 번짐', layoutGuide: '수채화 얼룩 배경, 손글씨 제목' },
  
  { id: 'neon_sign', name: '네온 사인', category: '크리에이티브', style: { bg: '#1A1A2E', text: '#FF6B6B', accent: '#4ECDC4', font: 'Pacifico' },
    mood: '카페 네온, 밤거리 간판', characteristics: ['네온 튜브 느낌', '글로우 효과', '손글씨 스타일', '밤 분위기'], texture: '벽돌 배경', layoutGuide: '네온 튜브 텍스트, 온/오프 느낌' },
  
  { id: 'risograph', name: '리소그래프', category: '크리에이티브', style: { bg: '#FFF8E1', text: '#E65100', accent: '#1565C0', font: 'Space Mono' },
    mood: '리소 프린트, 인디 포스터', characteristics: ['판화 느낌', '2-3색 레이어', '오프셋 효과', '그레인 텍스처'], texture: '리소 그레인', layoutGuide: '컬러 레이어 오프셋, 인쇄 느낌' },
  
  { id: 'abstract', name: '추상 미니멀', category: '크리에이티브', style: { bg: '#FAF5FF', text: '#1E1B4B', accent: '#7C3AED', font: 'Sora' },
    mood: '추상화, 모던 아트', characteristics: ['기하학 형태', '비정형 도형', '퍼플 포인트', '여백 활용'], texture: '없음', layoutGuide: '추상 도형 배경, 심플 텍스트' },
  
  { id: 'comic', name: '아메리칸 코믹', category: '크리에이티브', style: { bg: '#FFF500', text: '#000000', accent: '#FF0000', font: 'Bangers' },
    mood: 'Marvel/DC 코믹스', characteristics: ['하프톤 패턴', '말풍선', '액션 라인', '원색+검정'], texture: 'Ben-Day dots', layoutGuide: '폭발 효과, 굵은 테두리' },
  
  { id: 'sticker', name: '스티커 팩', category: '크리에이티브', style: { bg: '#E0F2FE', text: '#0C4A6E', accent: '#F472B6', font: 'Nunito' },
    mood: '카카오 이모티콘, 스티커', characteristics: ['귀여운 일러스트', '둥근 외곽선', '파스텔 톤', '장난스러움'], texture: '없음', layoutGuide: '스티커 형태 요소들, 흩뿌린 배치' },

  // ========== 학술 (6) ==========
  { id: 'academic', name: '학술 논문', category: '학술', style: { bg: '#fffbf0', text: '#3f3f46', accent: '#9f1239', font: 'Times New Roman' },
    mood: 'Harvard 논문, Nature', characteristics: ['세리프 본문', '정돈된 여백', '각주 스타일', '절제된 컬러'], texture: '아이보리 종이', layoutGuide: '중앙 정렬 제목, 저자/기관 하단' },
  
  { id: 'history', name: '역사 문서', category: '학술', style: { bg: '#e5e5e5', text: '#451a03', accent: '#78350f', font: 'Noto Serif KR' },
    mood: '고문서, 역사 다큐', characteristics: ['세피아 톤', '고풍 서체', '손상 효과', '문장 요소'], texture: '양피지 얼룩', layoutGuide: '양피지 배경, 테두리 장식' },
  
  { id: 'science', name: '사이언스 랩', category: '학술', style: { bg: '#0f172a', text: '#38bdf8', accent: '#22d3ee', font: 'Roboto' },
    mood: 'MIT Media Lab, 과학 저널', characteristics: ['데이터 시각화', '회로/분자 모티프', '테크 블루', '정밀 그리드'], texture: '회로 패턴', layoutGuide: '다크 배경, 시안 강조, 분자 장식' },
  
  { id: 'math', name: '수학 공식', category: '학술', style: { bg: '#1E293B', text: '#F8FAFC', accent: '#38BDF8', font: 'JetBrains Mono' },
    mood: '수학 교재, 칠판', characteristics: ['모노스페이스', '수식 레이아웃', '다크 배경', '분필 느낌'], texture: '칠판 텍스처', layoutGuide: '수식 중앙 배치, 분필 스타일' },
  
  { id: 'thesis', name: '학위논문', category: '학술', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#1E40AF', font: 'Linux Libertine' },
    mood: '대학원 논문, 학술 발표', characteristics: ['전통 학술 폰트', '넘버링 시스템', '각주/인용', '페이지 구조'], texture: '없음', layoutGuide: '논문 표지 형식, 대학 로고 위치' },
  
  { id: 'encyclopedia', name: '백과사전', category: '학술', style: { bg: '#F5F5DC', text: '#2F2F2F', accent: '#8B4513', font: 'Libre Baskerville' },
    mood: '브리태니커, 도감', characteristics: ['다단 레이아웃', '삽화 스타일', '빈티지 학술', '크로스레퍼런스'], texture: '오래된 책', layoutGuide: '컬럼 레이아웃, 삽화 영역' },

  // ========== 카툰 (8) ==========
  { id: 'sunday_comics', name: '선데이 코믹스', category: '카툰', style: { bg: '#FFFEF5', text: '#2D2D2D', accent: '#FF6B35', font: 'Comic Neue' },
    mood: '신문 연재만화, 피너츠/가필드', characteristics: ['4컷 구성', '깔끔한 선', '말풍선 대화', '유머러스'], texture: '신문지 질감', layoutGuide: '컷 분할, 캐릭터 중심' },
  
  { id: 'anime', name: '애니메이션', category: '카툰', style: { bg: '#fff', text: '#000', accent: '#db2777', font: 'Nunito' },
    mood: '지브리, 일본 애니', characteristics: ['소프트 그라데이션', '빛나는 하이라이트', '파스텔+비비드', '동적 구도'], texture: '글로우 파티클', layoutGuide: '대각선 레이아웃, 반짝임 효과' },
  
  { id: 'clay', name: '클레이 3D', category: '카툰', style: { bg: '#f1f5f9', text: '#475569', accent: '#818cf8', font: 'Nunito' },
    mood: '닌텐도 Kirby, 클레이 렌더', characteristics: ['부드러운 라운드', '파스텔 컬러', '소프트 그림자', '촉감적 느낌'], texture: '클레이 표면', layoutGuide: '둥근 3D 오브젝트, 파스텔 배경' },
  
  { id: 'lowpoly', name: '로우 폴리', category: '카툰', style: { bg: '#1e293b', text: '#e2e8f0', accent: '#14b8a6', font: 'Share Tech Mono' },
    mood: 'Monument Valley, 폴리곤 아트', characteristics: ['삼각형 면', '플랫 셰이딩', '그라데이션 면', '기하학 풍경'], texture: '없음', layoutGuide: '로우폴리 배경, 면 처리 타이틀' },
  
  { id: 'chibi', name: '치비 캐릭터', category: '카툰', style: { bg: '#FFF0F5', text: '#1A1A2E', accent: '#FF69B4', font: 'Varela Round' },
    mood: '귀여운 캐릭터, SD 캐릭터', characteristics: ['큰 머리 비율', '동글동글', '핑크 톤', '이모티콘 스타일'], texture: '없음', layoutGuide: '캐릭터 중심, 하트/별 장식' },
  
  { id: 'webtoon', name: '웹툰 스타일', category: '카툰', style: { bg: '#FFFFFF', text: '#000000', accent: '#FF5722', font: 'Nanum Gothic' },
    mood: '네이버 웹툰, 디지털 만화', characteristics: ['깔끔한 선', '풀컬러', '스크롤 최적화', '현대적 만화'], texture: '없음', layoutGuide: '세로 스크롤 구도, 말풍선 배치' },
  
  { id: 'doodle', name: '두들 낙서', category: '카툰', style: { bg: '#FFFEF5', text: '#1F2937', accent: '#EF4444', font: 'Architects Daughter' },
    mood: '노트 낙서, 손그림', characteristics: ['펜 스케치 느낌', '불완전한 선', '노트 배경', '화살표/별표'], texture: '노트 줄', layoutGuide: '노트 위 낙서 스타일' },
  
  { id: 'cartoon_retro', name: '빈티지 카툰', category: '카툰', style: { bg: '#FDF6E3', text: '#5C4033', accent: '#D2691E', font: 'Luckiest Guy' },
    mood: '1930s 디즈니, 고전 애니', characteristics: ['고무호스 스타일', '세피아 톤', '빈티지 캐릭터', '필름 그레인'], texture: '오래된 필름', layoutGuide: '빈티지 프레임, 필름 스크래치' },

  // ========== 테크니컬 (8) ==========
  { id: 'blueprint', name: '건축 청사진', category: '테크니컬', style: { bg: '#1e3a8a', text: '#ffffff', accent: '#93c5fd', font: 'Courier New' },
    mood: '건축 설계도, CAD', characteristics: ['파란 배경+흰 라인', '기술 도면', '치수선/주석', '모노스페이스'], texture: '청사진 그리드', layoutGuide: '점선 테두리, 도면 제목 블록' },
  
  { id: 'circuit', name: 'PCB 회로', category: '테크니컬', style: { bg: '#064e3b', text: '#34d399', accent: '#fbbf24', font: 'Share Tech' },
    mood: 'PCB 기판, 전자회로', characteristics: ['녹색/검정', '회로 패턴', '납땜 포인트', '부품 심볼'], texture: '회로 패턴', layoutGuide: '회로 라인이 제목 연결, LED 포인트' },
  
  { id: 'infographic', name: '인포그래픽', category: '테크니컬', style: { bg: '#f8fafc', text: '#334155', accent: '#6366f1', font: 'Roboto' },
    mood: 'Google Material, 데이터 시각화', characteristics: ['플랫 아이콘', '밝은 컬러', '명확한 계층', '심플 차트'], texture: '없음', layoutGuide: '아이콘+제목 조합, 플랫 스타일' },
  
  { id: 'map', name: '지형 지도', category: '테크니컬', style: { bg: '#fff', text: '#4b5563', accent: '#ef4444', font: 'Inter' },
    mood: 'National Geographic 지도', characteristics: ['등고선', '위치 마커', '경로 표시', '지도 컬러'], texture: '지형 패턴', layoutGuide: '지도 배경, 빨간 마커' },
  
  { id: 'dashboard', name: '대시보드 UI', category: '테크니컬', style: { bg: '#111827', text: '#F9FAFB', accent: '#10B981', font: 'Inter' },
    mood: 'Grafana, 관제 시스템', characteristics: ['다크 UI', '실시간 데이터', '그래프 위젯', '상태 표시'], texture: '없음', layoutGuide: '카드 그리드, 숫자 강조' },
  
  { id: 'code', name: '코드 에디터', category: '테크니컬', style: { bg: '#1E1E1E', text: '#D4D4D4', accent: '#569CD6', font: 'Fira Code' },
    mood: 'VS Code, 개발자 IDE', characteristics: ['모노스페이스', '신택스 하이라이팅', '다크 테마', '라인 넘버'], texture: '없음', layoutGuide: '코드 블록 스타일, 컬러 키워드' },
  
  { id: 'terminal', name: '터미널', category: '테크니컬', style: { bg: '#000000', text: '#00FF00', accent: '#00FF00', font: 'IBM Plex Mono' },
    mood: 'Matrix, 해커 터미널', characteristics: ['검정 배경', '녹색 텍스트', '커서 깜빡임', '명령어 스타일'], texture: 'CRT 스캔라인', layoutGuide: '$ 프롬프트, 타이핑 효과' },
  
  { id: 'diagram', name: '플로우차트', category: '테크니컬', style: { bg: '#FFFFFF', text: '#374151', accent: '#3B82F6', font: 'Nunito Sans' },
    mood: 'Miro, 프로세스 다이어그램', characteristics: ['도형 연결', '화살표 플로우', '컬러 노드', '명확한 구조'], texture: '없음', layoutGuide: '박스 연결, 화살표 흐름' },

  // ========== 크래프트 (6) ==========
  { id: 'sketch', name: '스케치북', category: '크래프트', style: { bg: '#ffffff', text: '#57534e', accent: '#ef4444', font: 'Permanent Marker' },
    mood: '디자이너 스케치북, 브레인스토밍', characteristics: ['연필/펜 드로잉', '거친 선', '메모/화살표', '낙서 느낌'], texture: '스케치북 종이', layoutGuide: '손글씨 제목, 동그라미/화살표 강조' },
  
  { id: 'vintage_paper', name: '빈티지 타자기', category: '크래프트', style: { bg: '#f5f5dc', text: '#4a4a4a', accent: '#8b4513', font: 'Courier Prime' },
    mood: '오래된 타자기, 빈티지 문서', characteristics: ['타자기 폰트', '바랜 종이', '잉크 번짐', '스탬프'], texture: '오래된 종이+커피 얼룩', layoutGuide: '타자기체 제목, 문서 스탬프' },
  
  { id: 'origami', name: '종이접기', category: '크래프트', style: { bg: '#fff', text: '#333', accent: '#f97316', font: 'Quicksand' },
    mood: '오리가미, 페이퍼아트', characteristics: ['종이 접힘', '그림자 입체감', '폴드 라인', '파스텔/화이트'], texture: '종이 질감', layoutGuide: '종이접기 형태, 그림자 표현' },
  
  { id: 'embroidery', name: '자수 패턴', category: '크래프트', style: { bg: '#FFFEF5', text: '#1F2937', accent: '#DC2626', font: 'Lora' },
    mood: '십자수, 자수 공예', characteristics: ['스티치 패턴', '천 텍스처', '전통 문양', '수공예 느낌'], texture: '린넨 천', layoutGuide: '자수 프레임, 스티치 텍스트' },
  
  { id: 'woodblock', name: '목판화', category: '크래프트', style: { bg: '#FDF6E3', text: '#1A1A1A', accent: '#8B0000', font: 'Crimson Text' },
    mood: '전통 목판 인쇄, 우키요에', characteristics: ['판화 텍스처', '제한된 색상', '강한 윤곽선', '전통 느낌'], texture: '나무결+잉크 번짐', layoutGuide: '목판 스타일 일러스트, 한자 느낌' },
  
  { id: 'letterpress', name: '활판 인쇄', category: '크래프트', style: { bg: '#F5F5F0', text: '#2D2D2D', accent: '#B8860B', font: 'Josefin Sans' },
    mood: '활자 인쇄, 명함 프레스', characteristics: ['눌린 자국', '잉크 불균일', '클래식 타이포', '장인 느낌'], texture: '압인 효과', layoutGuide: '눌린 텍스트 효과, 심플 레이아웃' },

  // ========== 재미 (8) ==========
  { id: 'secret', name: '1급 기밀', category: '재미', style: { bg: '#f3f3f3', text: '#000000', accent: '#ff0000', font: 'Special Elite' },
    mood: 'CIA 문서, 스파이 영화', characteristics: ['검열 마킹', 'TOP SECRET 스탬프', '파일 폴더', '타자기 폰트'], texture: '오래된 서류', layoutGuide: '"TOP SECRET" 스탬프, 검열 바' },
  
  { id: 'warning', name: '위험 경고', category: '재미', style: { bg: '#fbbf24', text: '#000000', accent: '#000000', font: 'Bangers' },
    mood: '공사장 경고, 위험 표지', characteristics: ['노랑/검정 줄무늬', '경고 아이콘', '대문자 볼드', '빨간 강조'], texture: '금속 표면', layoutGuide: '대각선 테두리, ⚠️ 아이콘' },
  
  { id: 'kid', name: '어린이 그림', category: '재미', style: { bg: '#fff', text: '#000', accent: '#f472b6', font: 'Comic Neue' },
    mood: '그림일기, 초등학교 게시판', characteristics: ['크레용 느낌', '무지개 색', '귀여운 그림', '손글씨'], texture: '도화지', layoutGuide: '🌈⭐ 장식, 동글동글 글씨' },
  
  { id: 'bsod', name: '블루스크린', category: '재미', style: { bg: '#0000AA', text: '#FFFFFF', accent: '#FFFFFF', font: 'Courier Prime' },
    mood: 'Windows 에러, 시스템 오류', characteristics: ['파란 배경 #0000AA', '흰색 고정폭', '에러 코드', '시스템 메시지'], texture: 'CRT 느낌', layoutGuide: 'BSOD 레이아웃, STOP 코드' },
  
  { id: 'win95', name: '윈도우 95', category: '재미', style: { bg: '#008080', text: '#000', accent: '#c0c0c0', font: 'MS Sans Serif' },
    mood: 'Windows 95/98 UI', characteristics: ['회색 UI', '3D 버튼', '클래식 아이콘', '시스템 폰트'], texture: '없음', layoutGuide: '윈도우 타이틀바, 확인/취소 버튼' },
  
  { id: 'loading', name: '로딩 스크린', category: '재미', style: { bg: '#000000', text: '#FFFFFF', accent: '#00FF00', font: 'Press Start 2P' },
    mood: 'PS1 로딩, 게임 부팅', characteristics: ['프로그레스 바', '팁 메시지', '게임 폰트', '대기 화면'], texture: '없음', layoutGuide: '로딩 바, "Please Wait" 메시지' },
  
  { id: 'receipt', name: '영수증', category: '재미', style: { bg: '#FFFEF5', text: '#000000', accent: '#000000', font: 'Courier New' },
    mood: '마트 영수증, 주문서', characteristics: ['모노스페이스', '점선 구분', '가격 정렬', '열전사 느낌'], texture: '영수증 종이', layoutGuide: '영수증 형식, 가격 우측 정렬' },
  
  { id: 'meme', name: '밈 템플릿', category: '재미', style: { bg: '#FFFFFF', text: '#000000', accent: '#FF0000', font: 'Impact' },
    mood: '인터넷 밈, SNS 짤', characteristics: ['Impact 폰트', '상단/하단 텍스트', '검정 외곽선', '강렬한 임팩트'], texture: '없음', layoutGuide: '상단 텍스트 + 하단 텍스트 구조' },

  // ========== 강의교안 (10) ==========
  { id: 'university', name: '대학 강의', category: '강의교안', style: { bg: '#FFFFFF', text: '#1E3A5F', accent: '#8B0000', font: 'Noto Serif KR' },
    mood: '서울대/연세대 강의자료, 학술 강연', characteristics: ['세리프 제목', '번호 매기기', '인용문 박스', '각주 스타일'], texture: '없음', layoutGuide: '상단 강의명, 중앙 내용, 하단 페이지/교수명' },

  { id: 'corporate_training', name: '기업 연수', category: '강의교안', style: { bg: '#F8FAFC', text: '#0F172A', accent: '#0066CC', font: 'Pretendard' },
    mood: '삼성/LG 사내교육, HRD 연수원', characteristics: ['회사 CI 컬러', '학습목표 박스', '체크리스트', '요약 정리'], texture: '없음', layoutGuide: '좌상단 로고 영역, 학습목표 강조, 핵심내용 박스' },

  { id: 'workshop', name: '실습 워크샵', category: '강의교안', style: { bg: '#FEF3C7', text: '#78350F', accent: '#D97706', font: 'Noto Sans KR' },
    mood: '디자인씽킹, 애자일 워크샵', characteristics: ['스티커노트 느낌', '손글씨 믹스', '화살표/다이어그램', '참여 유도'], texture: '코르크보드 hint', layoutGuide: '포스트잇 스타일 박스, 활동 지시문 강조' },

  { id: 'online_lecture', name: '온라인 강의', category: '강의교안', style: { bg: '#18181B', text: '#FFFFFF', accent: '#22C55E', font: 'Inter' },
    mood: '클래스101, 인프런, 유데미', characteristics: ['다크모드 친화', '섹션 구분 명확', '진행바 표시', '키포인트 강조'], texture: '없음', layoutGuide: '좌측 챕터 표시, 중앙 대형 텍스트, 하단 진행률' },

  { id: 'ted_style', name: 'TED 스타일', category: '강의교안', style: { bg: '#000000', text: '#FFFFFF', accent: '#EB0028', font: 'Helvetica Neue' },
    mood: 'TED Talk, 대형 컨퍼런스', characteristics: ['한 슬라이드 한 메시지', '대형 이미지', '임팩트 문구', '스토리텔링'], texture: '없음', layoutGuide: '중앙 한 문장, 풀스크린 이미지, 빨간 강조' },

  { id: 'chalkboard', name: '칠판 스타일', category: '강의교안', style: { bg: '#2D4739', text: '#FFFFFF', accent: '#FFE066', font: 'Gaegu' },
    mood: '학교 칠판, 손글씨 강의', characteristics: ['초록 칠판 배경', '분필 텍스처', '손글씨 폰트', '밑줄 강조'], texture: '칠판 노이즈', layoutGuide: '손글씨 제목, 노란 분필 강조, 지우개 자국' },

  { id: 'flip_learning', name: '플립러닝', category: '강의교안', style: { bg: '#EFF6FF', text: '#1E40AF', accent: '#3B82F6', font: 'Spoqa Han Sans' },
    mood: '사전학습 자료, 예습 콘텐츠', characteristics: ['QR코드 영역', '영상 링크 박스', '퀴즈 프레임', '자기점검 체크'], texture: '없음', layoutGuide: '상단 학습목표, 중앙 핵심개념, 하단 사전질문' },

  { id: 'coding_bootcamp', name: '코딩 부트캠프', category: '강의교안', style: { bg: '#1E1E1E', text: '#D4D4D4', accent: '#569CD6', font: 'Fira Code' },
    mood: '프로그래밍 강의, 개발자 교육', characteristics: ['코드 블록 스타일', '신택스 하이라이팅', '터미널 느낌', '단계별 설명'], texture: '없음', layoutGuide: '코드 에디터 레이아웃, 라인넘버, 주석 설명' },

  { id: 'kids_class', name: '키즈 클래스', category: '강의교안', style: { bg: '#FFF7ED', text: '#9A3412', accent: '#FB923C', font: 'Jua' },
    mood: '초등교육, 어린이 학습지', characteristics: ['둥근 모서리', '귀여운 아이콘', '큰 글씨', '컬러풀 포인트'], texture: '없음', layoutGuide: '캐릭터 영역, 말풍선 설명, 활동 박스' },

  { id: 'seminar_pro', name: '전문 세미나', category: '강의교안', style: { bg: '#FAFAF9', text: '#292524', accent: '#7C3AED', font: 'Noto Sans KR' },
    mood: '의료/법률/금융 전문가 세미나', characteristics: ['데이터 표/차트', '출처 명시', '전문 용어 박스', '참고문헌'], texture: '없음', layoutGuide: '상단 세션명, 발표자 정보, 근거자료 인용 스타일' },

  // ========== 종교/영성 (10) ==========
  { id: 'bible_story', name: '성경 이야기', category: '종교', style: { bg: '#FDF6E3', text: '#5C4033', accent: '#8B4513', font: 'Noto Serif KR' },
    mood: '성경동화, 주일학교 교재', characteristics: ['따뜻한 파피루스 톤', '세리프 본문', '성경 인용 박스', '챕터 구분'], texture: '양피지 질감', layoutGuide: '상단 성경 구절, 중앙 내용, 하단 말씀 요약' },

  { id: 'church_worship', name: '교회 예배', category: '종교', style: { bg: '#1a1a2e', text: '#FFFFFF', accent: '#FFD700', font: 'Noto Sans KR' },
    mood: '예배 순서, 주보, 찬양 PPT', characteristics: ['경건한 다크톤', '금색 포인트', '십자가 모티프', '은은한 광선'], texture: '스테인드글라스 hint', layoutGuide: '중앙 정렬, 상단 찬양 제목, 하단 가사' },

  { id: 'sermon', name: '설교 노트', category: '종교', style: { bg: '#FFFEF7', text: '#2C2C2C', accent: '#6B4423', font: 'Noto Serif KR' },
    mood: '목사님 설교, 강해 자료', characteristics: ['깔끔한 여백', '본문 강조', '포인트 번호', '적용 박스'], texture: '크림지 질감', layoutGuide: '성경본문 상단, 3대지 구조, 적용점 하단' },

  { id: 'bible_study', name: '성경 공부', category: '종교', style: { bg: '#F5F1EB', text: '#3D3D3D', accent: '#7B5544', font: 'Noto Sans KR' },
    mood: 'QT 자료, 소그룹 성경공부', characteristics: ['질문 박스', '묵상 포인트', '나눔 가이드', '기도제목'], texture: '노트 라인', layoutGuide: '본문-관찰-해석-적용 구조' },

  { id: 'praise', name: '찬양 가사', category: '종교', style: { bg: '#0D1B2A', text: '#FFFFFF', accent: '#48CAE4', font: 'Pretendard' },
    mood: '찬양팀, 워십 가사 PPT', characteristics: ['어두운 배경', '큰 가사 텍스트', '은은한 그라데이션', '절 구분'], texture: '빛 그라데이션', layoutGuide: '가사 중앙 대형, 절 번호 좌상단' },

  { id: 'stained_glass', name: '스테인드글라스', category: '종교', style: { bg: '#1C1C1C', text: '#FFFFFF', accent: '#E6BE8A', font: 'Cormorant' },
    mood: '성당, 전통 교회 분위기', characteristics: ['화려한 색유리 느낌', '고딕 장식', '성화 스타일', '경건한 분위기'], texture: '유리 빛 반사', layoutGuide: '아치형 프레임, 중앙 메시지' },

  { id: 'parchment', name: '양피지 성경', category: '종교', style: { bg: '#F4E4BC', text: '#4A3728', accent: '#8B0000', font: 'Times New Roman' },
    mood: '고대 성경, 두루마리 느낌', characteristics: ['에이징 효과', '캘리그라피', '붉은 첫 글자', '테두리 장식'], texture: '오래된 종이', layoutGuide: '두루마리 형태, 장식 테두리' },

  { id: 'meditation', name: '묵상 일지', category: '종교', style: { bg: '#FAF8F5', text: '#4A4A4A', accent: '#9CAF88', font: 'Noto Serif KR' },
    mood: '개인 묵상, 영성 일기', characteristics: ['차분한 톤', '자연 요소', '여백 많음', '손글씨 느낌'], texture: '수채화 워시', layoutGuide: '날짜 상단, 말씀-묵상-기도 구조' },

  { id: 'sunday_school', name: '주일학교', category: '종교', style: { bg: '#FFF9E6', text: '#5D4E37', accent: '#FF8C00', font: 'Jua' },
    mood: '어린이 주일학교, 유치부', characteristics: ['밝은 색상', '귀여운 일러스트', '큰 글씨', '활동 박스'], texture: '없음', layoutGuide: '캐릭터 삽입, 색칠 영역, 말풍선' },

  { id: 'easter_christmas', name: '절기 (부활/성탄)', category: '종교', style: { bg: '#0F4C3A', text: '#FFFFFF', accent: '#FFD700', font: 'Playfair Display' },
    mood: '부활절, 성탄절 특별 예배', characteristics: ['절기 색상', '축제 분위기', '별/십자가', '특별 장식'], texture: '눈/꽃잎 효과', layoutGuide: '중앙 메시지, 장식 프레임' },

  // ========== 소셜미디어 (8) ==========
  { id: 'insta_carousel', name: '인스타 캐러셀', category: '소셜미디어', style: { bg: '#FFFFFF', text: '#262626', accent: '#E1306C', font: 'Pretendard' },
    mood: '인스타그램 슬라이드 게시물', characteristics: ['1:1 비율 최적화', '스와이프 유도', '깔끔한 카드', 'CTA 마지막장'], texture: '없음', layoutGuide: '한 장 한 메시지, 번호 표시' },

  { id: 'youtube_thumb', name: '유튜브 썸네일', category: '소셜미디어', style: { bg: '#FF0000', text: '#FFFFFF', accent: '#FFFF00', font: 'Black Han Sans' },
    mood: '유튜브 썸네일, 영상 표지', characteristics: ['강렬한 대비', '큰 텍스트', '얼굴 영역', '클릭 유도'], texture: '없음', layoutGuide: '3분할 구성, 핵심 키워드 강조' },

  { id: 'tiktok', name: '틱톡 스타일', category: '소셜미디어', style: { bg: '#000000', text: '#FFFFFF', accent: '#69C9D0', font: 'Montserrat' },
    mood: '틱톡, 숏폼 콘텐츠', characteristics: ['세로형 최적화', '네온 포인트', '빠른 전환', '트렌디'], texture: '글리치 효과', layoutGuide: '세로 중앙, 짧은 문구' },

  { id: 'linkedin', name: '링크드인', category: '소셜미디어', style: { bg: '#F3F2EF', text: '#000000', accent: '#0A66C2', font: 'SF Pro Display' },
    mood: '링크드인 게시물, 비즈니스 SNS', characteristics: ['전문적 톤', '깔끔한 레이아웃', '데이터 강조', '신뢰감'], texture: '없음', layoutGuide: '헤드라인 상단, 핵심 수치 강조' },

  { id: 'twitter', name: '트위터/X', category: '소셜미디어', style: { bg: '#15202B', text: '#FFFFFF', accent: '#1DA1F2', font: 'Chirp' },
    mood: '트위터 스레드, X 게시물', characteristics: ['다크모드', '짧은 문장', '해시태그', '인용 스타일'], texture: '없음', layoutGuide: '트윗 형식, 280자 제한 느낌' },

  { id: 'pinterest', name: '핀터레스트', category: '소셜미디어', style: { bg: '#FFFFFF', text: '#211922', accent: '#E60023', font: 'Noto Sans KR' },
    mood: '핀터레스트 핀, 무드보드', characteristics: ['세로형 이미지', '영감 중심', '컬렉션 느낌', '미니멀'], texture: '없음', layoutGuide: '이미지 중심, 하단 설명' },

  { id: 'brunch', name: '브런치 매거진', category: '소셜미디어', style: { bg: '#FFFFFF', text: '#333333', accent: '#00C3BD', font: 'Nanum Myeongjo' },
    mood: '브런치 글, 에세이 스타일', characteristics: ['긴 호흡', '여백 미학', '세리프 본문', '문학적'], texture: '종이 질감', layoutGuide: '좌측 정렬, 넉넉한 행간' },

  { id: 'newsletter', name: '뉴스레터', category: '소셜미디어', style: { bg: '#F9FAFB', text: '#111827', accent: '#6366F1', font: 'Inter' },
    mood: '이메일 뉴스레터, 서브스택', characteristics: ['읽기 쉬운 구조', '섹션 구분', '하이라이트', 'CTA 버튼'], texture: '없음', layoutGuide: '헤더-본문-푸터 구조' },

  // ========== 이벤트 (8) ==========
  { id: 'wedding', name: '웨딩', category: '이벤트', style: { bg: '#FDF8F5', text: '#5C4033', accent: '#D4AF37', font: 'Cormorant Garamond' },
    mood: '청첩장, 웨딩 안내', characteristics: ['로맨틱 세리프', '골드 포인트', '플로럴 장식', '우아함'], texture: '린넨 질감', layoutGuide: '중앙 정렬, 날짜 강조, 장식 프레임' },

  { id: 'birthday', name: '생일 파티', category: '이벤트', style: { bg: '#FFE5EC', text: '#4A4A4A', accent: '#FF69B4', font: 'Jua' },
    mood: '생일 초대장, 파티 안내', characteristics: ['축하 분위기', '풍선/케이크', '밝은 색상', '재미있는 폰트'], texture: '컨페티 효과', layoutGuide: '이름 크게, 날짜/장소 명확' },

  { id: 'graduation', name: '졸업식', category: '이벤트', style: { bg: '#1A237E', text: '#FFFFFF', accent: '#FFD700', font: 'Playfair Display' },
    mood: '졸업 축하, 학위 수여', characteristics: ['격식 있는 톤', '금색 포인트', '학사모 모티프', '성취감'], texture: '없음', layoutGuide: '중앙 축하 메시지, 연도 강조' },

  { id: 'doljanchi', name: '돌잔치', category: '이벤트', style: { bg: '#FFF5E6', text: '#8B4513', accent: '#FF6B6B', font: 'Gowun Batang' },
    mood: '돌잔치 초대장, 아기 행사', characteristics: ['전통+현대 믹스', '파스텔톤', '귀여운 요소', '가족 따뜻함'], texture: '한지 느낌', layoutGuide: '아기 이름 중앙, 돌상 이미지' },

  { id: 'corporate_event', name: '기업 행사', category: '이벤트', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#2563EB', font: 'Pretendard' },
    mood: '기업 행사, 런칭 이벤트', characteristics: ['프로페셔널', '브랜드 컬러', '깔끔한 정보', '일정 안내'], texture: '없음', layoutGuide: '로고 상단, 일정표 구조' },

  { id: 'yearend', name: '송년회/신년회', category: '이벤트', style: { bg: '#0C0C1E', text: '#FFFFFF', accent: '#FFD700', font: 'Montserrat' },
    mood: '송년회, 신년회, 연말 파티', characteristics: ['축제 분위기', '금색/은색', '불꽃놀이', '카운트다운'], texture: '반짝임 효과', layoutGuide: '연도 크게, 축하 메시지' },

  { id: 'seminar_invite', name: '세미나 초대', category: '이벤트', style: { bg: '#F8FAFC', text: '#0F172A', accent: '#8B5CF6', font: 'Inter' },
    mood: '세미나, 컨퍼런스 초대장', characteristics: ['전문적 톤', '연사 정보', '일정 명확', '등록 CTA'], texture: '없음', layoutGuide: '타이틀-연사-일정-등록 구조' },

  { id: 'exhibition', name: '전시회', category: '이벤트', style: { bg: '#FFFFFF', text: '#000000', accent: '#FF4444', font: 'Helvetica Neue' },
    mood: '전시회, 갤러리 초대', characteristics: ['아트 갤러리 느낌', '미니멀', '작품 중심', '여백 활용'], texture: '없음', layoutGuide: '작품명 중앙, 날짜/장소 하단' },

  // ========== 여행 (6) ==========
  { id: 'travel_guide', name: '여행 가이드', category: '여행', style: { bg: '#E8F4F8', text: '#2C3E50', accent: '#E74C3C', font: 'Noto Sans KR' },
    mood: '여행 가이드북, 관광 안내', characteristics: ['지도 요소', '아이콘 활용', '코스 안내', '팁 박스'], texture: '없음', layoutGuide: '목적지 헤더, 코스별 구분' },

  { id: 'travel_journal', name: '여행 일지', category: '여행', style: { bg: '#FDF6E3', text: '#5D4E37', accent: '#27AE60', font: 'Gowun Dodum' },
    mood: '여행 일기, 포토 에세이', characteristics: ['손글씨 믹스', '사진 프레임', '스탬프 효과', '날짜 기록'], texture: '빈티지 종이', layoutGuide: '날짜 상단, 사진+글 조합' },

  { id: 'hotel', name: '호텔 소개', category: '여행', style: { bg: '#1A1A1A', text: '#FFFFFF', accent: '#C9A962', font: 'Playfair Display' },
    mood: '럭셔리 호텔, 리조트 소개', characteristics: ['고급스러움', '골드 포인트', '객실 정보', '어메니티'], texture: '없음', layoutGuide: '풀스크린 이미지, 오버레이 텍스트' },

  { id: 'airline', name: '항공사', category: '여행', style: { bg: '#003366', text: '#FFFFFF', accent: '#FFD700', font: 'Montserrat' },
    mood: '항공사, 비행 안내', characteristics: ['스카이 블루', '구름 모티프', '노선 정보', '클래스 구분'], texture: '하늘 그라데이션', layoutGuide: '목적지 크게, 비행 정보 표' },

  { id: 'national_park', name: '국립공원', category: '여행', style: { bg: '#2D5016', text: '#FFFFFF', accent: '#F4A460', font: 'Merriweather' },
    mood: '국립공원, 자연 관광', characteristics: ['자연 색상', '야생동물', '트레일 정보', '보존 메시지'], texture: '나뭇결 hint', layoutGuide: '파노라마 이미지, 정보 카드' },

  { id: 'city_tour', name: '시티 투어', category: '여행', style: { bg: '#FFFFFF', text: '#333333', accent: '#FF6B6B', font: 'Poppins' },
    mood: '도시 여행, 시티 가이드', characteristics: ['랜드마크 아이콘', '지하철 노선', '핫플레이스', '시간별 코스'], texture: '없음', layoutGuide: '지도 중심, 스팟 번호' },

  // ========== 음식 (6) ==========
  { id: 'recipe', name: '레시피북', category: '음식', style: { bg: '#FFFAF0', text: '#4A4A4A', accent: '#E67E22', font: 'Noto Sans KR' },
    mood: '요리 레시피, 쿡북', characteristics: ['재료 체크리스트', '단계별 설명', '팁 박스', '인분 표시'], texture: '주방 린넨', layoutGuide: '재료 좌측, 순서 우측' },

  { id: 'menu', name: '메뉴판', category: '음식', style: { bg: '#1C1C1C', text: '#F5F5DC', accent: '#D4AF37', font: 'Cormorant' },
    mood: '레스토랑 메뉴, 다이닝', characteristics: ['우아한 타이포', '가격 정렬', '코스 구분', '와인 페어링'], texture: '가죽 질감', layoutGuide: '카테고리별 구분, 가격 우측 정렬' },

  { id: 'cafe', name: '카페', category: '음식', style: { bg: '#F5E6D3', text: '#5D4037', accent: '#8D6E63', font: 'Gowun Dodum' },
    mood: '카페 메뉴, 디저트 소개', characteristics: ['커피 브라운', '손글씨 믹스', '일러스트', '가격표'], texture: '커피 얼룩 hint', layoutGuide: '음료 이미지 + 설명' },

  { id: 'fine_dining', name: '파인 다이닝', category: '음식', style: { bg: '#0D0D0D', text: '#FFFFFF', accent: '#B8860B', font: 'Didot' },
    mood: '미슐랭, 고급 레스토랑', characteristics: ['미니멀 럭셔리', '코스 요리', '쉐프 소개', '예약 안내'], texture: '없음', layoutGuide: '요리 사진 중심, 설명 최소화' },

  { id: 'food_blog', name: '푸드 블로그', category: '음식', style: { bg: '#FFFFFF', text: '#333333', accent: '#FF6347', font: 'Pretendard' },
    mood: '맛집 리뷰, 푸드 콘텐츠', characteristics: ['사진 중심', '별점 표시', '위치 정보', '솔직한 리뷰'], texture: '없음', layoutGuide: '음식 사진 크게, 정보 하단' },

  { id: 'cooking_class', name: '쿠킹 클래스', category: '음식', style: { bg: '#FFF8DC', text: '#2F4F4F', accent: '#FF4500', font: 'Noto Sans KR' },
    mood: '요리 교실, 쿠킹 스튜디오', characteristics: ['단계별 사진', '도구 설명', '주의사항', '완성 이미지'], texture: '앞치마 패턴', layoutGuide: 'Step 1-2-3 구조' },

  // ========== 스포츠 (6) ==========
  { id: 'game_analysis', name: '경기 분석', category: '스포츠', style: { bg: '#1A1A2E', text: '#FFFFFF', accent: '#00FF87', font: 'Roboto' },
    mood: '스포츠 분석, 전술 보드', characteristics: ['필드 다이어그램', '선수 포지션', '통계 그래프', '하이라이트'], texture: '잔디 패턴', layoutGuide: '경기장 뷰, 데이터 오버레이' },

  { id: 'team_intro', name: '팀 소개', category: '스포츠', style: { bg: '#002244', text: '#FFFFFF', accent: '#FFB81C', font: 'Bebas Neue' },
    mood: '스포츠팀, 구단 소개', characteristics: ['팀 컬러', '로스터 정보', '시즌 성적', '엠블럼'], texture: '없음', layoutGuide: '로고 중앙, 선수 카드 그리드' },

  { id: 'fitness', name: '피트니스', category: '스포츠', style: { bg: '#000000', text: '#FFFFFF', accent: '#FF4757', font: 'Oswald' },
    mood: '헬스장, 운동 프로그램', characteristics: ['강렬한 대비', '운동 루틴', '세트/횟수', '비포애프터'], texture: '없음', layoutGuide: '운동 이미지 + 설명 카드' },

  { id: 'golf', name: '골프', category: '스포츠', style: { bg: '#1B4D3E', text: '#FFFFFF', accent: '#F0E68C', font: 'Georgia' },
    mood: '골프장, 골프 레슨', characteristics: ['그린 색상', '코스 맵', '스윙 분석', '클래식한 느낌'], texture: '잔디 질감', layoutGuide: '코스 레이아웃, 홀 정보' },

  { id: 'running', name: '러닝', category: '스포츠', style: { bg: '#FF6B35', text: '#FFFFFF', accent: '#1A1A1A', font: 'Montserrat' },
    mood: '마라톤, 러닝 크루', characteristics: ['다이내믹', '페이스 정보', '코스 맵', '기록 표시'], texture: '없음', layoutGuide: '거리/시간 크게, 코스 지도' },

  { id: 'esports', name: 'e스포츠', category: '스포츠', style: { bg: '#0D0D0D', text: '#FFFFFF', accent: '#00FFFF', font: 'Rajdhani' },
    mood: '게임 대회, e스포츠 리그', characteristics: ['네온 글로우', '팀 대진표', '선수 프로필', '사이버 느낌'], texture: '디지털 노이즈', layoutGuide: '대진표 중심, 팀 로고' },

  // ========== 건강/웰빙 (6) ==========
  { id: 'hospital', name: '병원/의료', category: '건강/웰빙', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#0891B2', font: 'Noto Sans KR' },
    mood: '병원 안내, 의료 정보', characteristics: ['청결한 느낌', '아이콘 활용', '단계별 안내', '신뢰감'], texture: '없음', layoutGuide: '정보 카드 구조, 명확한 구분' },

  { id: 'yoga', name: '요가/명상', category: '건강/웰빙', style: { bg: '#F5F0E8', text: '#4A4A4A', accent: '#9CAF88', font: 'Cormorant' },
    mood: '요가 스튜디오, 명상 가이드', characteristics: ['평화로운 톤', '자연 요소', '호흡 가이드', '차분함'], texture: '린넨 질감', layoutGuide: '포즈 이미지 중심, 설명 하단' },

  { id: 'diet', name: '다이어트', category: '건강/웰빙', style: { bg: '#E8F5E9', text: '#2E7D32', accent: '#FF5722', font: 'Pretendard' },
    mood: '다이어트 플랜, 식단 관리', characteristics: ['칼로리 표시', '식단표', '운동 계획', '진행 그래프'], texture: '없음', layoutGuide: '주간 계획표, 체크리스트' },

  { id: 'mental_care', name: '멘탈 케어', category: '건강/웰빙', style: { bg: '#E8EAF6', text: '#3F51B5', accent: '#FF9800', font: 'Noto Sans KR' },
    mood: '심리 상담, 마음 건강', characteristics: ['부드러운 색상', '감정 표현', '자기돌봄 팁', '위로의 메시지'], texture: '수채화 워시', layoutGuide: '메시지 중앙, 여백 충분히' },

  { id: 'nutrition', name: '영양 정보', category: '건강/웰빙', style: { bg: '#FFFDE7', text: '#33691E', accent: '#F57C00', font: 'Roboto' },
    mood: '영양제, 건강식품 정보', characteristics: ['성분 표시', '효능 설명', '복용법', '인포그래픽'], texture: '없음', layoutGuide: '성분표 구조, 아이콘 활용' },

  { id: 'spa', name: '스파/뷰티', category: '건강/웰빙', style: { bg: '#FDF2F8', text: '#6B4C5A', accent: '#EC4899', font: 'Playfair Display' },
    mood: '스파, 뷰티살롱, 에스테틱', characteristics: ['럭셔리 느낌', '꽃/자연 요소', '시술 메뉴', '우아함'], texture: '대리석 hint', layoutGuide: '이미지 중심, 가격표 하단' },

  // ========== 키즈 (6) ==========
  { id: 'fairytale', name: '동화책', category: '키즈', style: { bg: '#FFF8E7', text: '#5D4E37', accent: '#FF9F43', font: 'Gowun Batang' },
    mood: '어린이 동화, 그림책', characteristics: ['따뜻한 일러스트', '큰 글씨', '말풍선', '페이지 넘버'], texture: '종이 질감', layoutGuide: '그림 좌측, 글 우측 또는 하단' },

  { id: 'early_education', name: '유아 교육', category: '키즈', style: { bg: '#E3F2FD', text: '#1565C0', accent: '#FF5722', font: 'Jua' },
    mood: '유치원, 어린이집 교재', characteristics: ['밝은 원색', '귀여운 캐릭터', '학습 활동', '스티커 영역'], texture: '없음', layoutGuide: '활동 박스, 따라하기 구조' },

  { id: 'alphabet', name: '알파벳/한글', category: '키즈', style: { bg: '#FFFFFF', text: '#333333', accent: '#4CAF50', font: 'Cafe24 Ssurround' },
    mood: 'ABC, 가나다 학습', characteristics: ['큰 글자', '연관 이미지', '따라쓰기 공간', '발음 표시'], texture: '없음', layoutGuide: '글자 크게 중앙, 예시 이미지' },

  { id: 'numbers', name: '숫자 놀이', category: '키즈', style: { bg: '#FFF3E0', text: '#E65100', accent: '#7B1FA2', font: 'Black Han Sans' },
    mood: '숫자 학습, 수학 놀이', characteristics: ['큰 숫자', '세기 활동', '색칠 영역', '게임 요소'], texture: '없음', layoutGuide: '숫자 중앙, 개수 세기 활동' },

  { id: 'coloring', name: '색칠 공부', category: '키즈', style: { bg: '#FFFFFF', text: '#666666', accent: '#E91E63', font: 'Noto Sans KR' },
    mood: '색칠놀이, 그리기 활동', characteristics: ['외곽선 아트', '넓은 영역', '색상 가이드', '완성 예시'], texture: '도화지 질감', layoutGuide: '색칠 영역 크게, 예시 작게' },

  { id: 'kids_bible', name: '어린이 성경', category: '키즈', style: { bg: '#E8F5E9', text: '#33691E', accent: '#FF9800', font: 'Gowun Dodum' },
    mood: '어린이 성경, 유아부 교재', characteristics: ['귀여운 성경 캐릭터', '쉬운 말씀', '색칠 활동', '기도문'], texture: '없음', layoutGuide: '그림 상단, 말씀 하단' },

  // ========== 포토 (6) ==========
  { id: 'wedding_album', name: '웨딩 앨범', category: '포토', style: { bg: '#FFFFFF', text: '#4A4A4A', accent: '#D4AF37', font: 'Cormorant Garamond' },
    mood: '웨딩 포토북, 결혼 앨범', characteristics: ['우아한 프레임', '날짜 표시', '캡션 영역', '로맨틱'], texture: '린넨 질감', layoutGuide: '사진 중심, 최소 텍스트' },

  { id: 'family_photo', name: '가족 사진', category: '포토', style: { bg: '#FDF6E3', text: '#5C4033', accent: '#8B4513', font: 'Noto Serif KR' },
    mood: '가족 앨범, 돌잔치 사진', characteristics: ['따뜻한 톤', '성장 기록', '날짜 스탬프', '추억 느낌'], texture: '빈티지 종이', layoutGuide: '콜라주 레이아웃' },

  { id: 'portfolio_photo', name: '사진 포트폴리오', category: '포토', style: { bg: '#0A0A0A', text: '#FFFFFF', accent: '#FFFFFF', font: 'Helvetica Neue' },
    mood: '사진작가 포트폴리오', characteristics: ['풀스크린 이미지', '미니멀 캡션', '시리즈 구분', '갤러리 느낌'], texture: '없음', layoutGuide: '사진 전체 화면, 정보 최소화' },

  { id: 'bw_gallery', name: '흑백 갤러리', category: '포토', style: { bg: '#1A1A1A', text: '#FFFFFF', accent: '#808080', font: 'DM Sans' },
    mood: '흑백 사진전, 아트 갤러리', characteristics: ['모노크롬', '강한 대비', '아트 캡션', '전시 느낌'], texture: '필름 그레인', layoutGuide: '사진 중앙, 흰 테두리' },

  { id: 'film_camera', name: '필름 카메라', category: '포토', style: { bg: '#F5F0E1', text: '#333333', accent: '#C41E3A', font: 'Courier New' },
    mood: '아날로그 필름, 레트로 사진', characteristics: ['필름 프레임', '날짜 스탬프', '색바랜 느낌', '노이즈'], texture: '필름 스크래치', layoutGuide: '35mm 필름 프레임 형태' },

  { id: 'polaroid_book', name: '폴라로이드북', category: '포토', style: { bg: '#F9F6F0', text: '#333333', accent: '#E8E4DC', font: 'Caveat' },
    mood: '폴라로이드 콜라주, 인스턴트 사진', characteristics: ['흰 테두리', '손글씨 캡션', '테이프 효과', '랜덤 배치'], texture: '종이 질감', layoutGuide: '폴라로이드 프레임, 기울임' },

  // ========== 뮤직/공연 (8) ==========
  { id: 'concert_poster', name: '콘서트 포스터', category: '뮤직/공연', style: { bg: '#000000', text: '#FFFFFF', accent: '#FF1493', font: 'Impact' },
    mood: '콘서트 홍보, 공연 포스터', characteristics: ['대담한 타이포', '네온 컬러', '날짜 강조', '티켓 정보'], texture: '노이즈 그레인', layoutGuide: '아티스트명 크게, 일정 하단' },

  { id: 'album_art', name: '앨범 아트', category: '뮤직/공연', style: { bg: '#1A1A1A', text: '#FFFFFF', accent: '#6366F1', font: 'Helvetica Neue' },
    mood: '앨범 커버, 음반 아트워크', characteristics: ['정사각형 최적화', '아티스트 비주얼', '트랙리스트', '크레딧'], texture: '비닐 질감', layoutGuide: '이미지 전면, 정보 후면' },

  { id: 'musical', name: '뮤지컬', category: '뮤직/공연', style: { bg: '#2C0735', text: '#FFD700', accent: '#FF4081', font: 'Playfair Display' },
    mood: '뮤지컬 포스터, 공연 안내', characteristics: ['화려한 분위기', '스포트라이트', '캐스팅 정보', '극장 느낌'], texture: '벨벳 질감', layoutGuide: '작품명 상단, 캐스트 하단' },

  { id: 'orchestra', name: '오케스트라', category: '뮤직/공연', style: { bg: '#1C1C1C', text: '#F5F5DC', accent: '#CFB53B', font: 'Cormorant' },
    mood: '클래식 공연, 오케스트라', characteristics: ['격식 있는 느낌', '금색 포인트', '프로그램 안내', '지휘자 정보'], texture: '없음', layoutGuide: '곡목 리스트, 연주자 정보' },

  { id: 'dj_club', name: 'DJ/클럽', category: '뮤직/공연', style: { bg: '#0D0D0D', text: '#FFFFFF', accent: '#00FFFF', font: 'Orbitron' },
    mood: 'DJ 이벤트, 클럽 파티', characteristics: ['네온 글로우', '일렉트로닉', '라인업', '시간표'], texture: '레이저 효과', layoutGuide: 'DJ명 크게, 시간 정보' },

  { id: 'busking', name: '버스킹', category: '뮤직/공연', style: { bg: '#FFF8E7', text: '#2C2C2C', accent: '#FF6B35', font: 'Gowun Dodum' },
    mood: '거리 공연, 버스킹 안내', characteristics: ['친근한 느낌', '장소 정보', '아티스트 소개', '자유로운 레이아웃'], texture: '크래프트 종이', layoutGuide: '지도 포함, 일정 안내' },

  { id: 'festival', name: '음악 페스티벌', category: '뮤직/공연', style: { bg: '#FF6B6B', text: '#FFFFFF', accent: '#4ECDC4', font: 'Bebas Neue' },
    mood: '뮤직 페스티벌, 야외 공연', characteristics: ['여름 바이브', '라인업 포스터', '스테이지 맵', '타임테이블'], texture: '없음', layoutGuide: '헤드라이너 크게, 시간표 구조' },

  { id: 'band_intro', name: '밴드 소개', category: '뮤직/공연', style: { bg: '#1A1A1A', text: '#FFFFFF', accent: '#E53935', font: 'Anton' },
    mood: '밴드 프로필, 그룹 소개', characteristics: ['록 바이브', '멤버 소개', '디스코그래피', '투어 일정'], texture: '그런지 텍스처', layoutGuide: '밴드 사진, 멤버별 프로필' },

  // ========== 기존 카테고리 보강 ==========
  // 심플 +2
  { id: 'zero_ui', name: '제로 UI', category: '심플', style: { bg: '#FFFFFF', text: '#000000', accent: '#000000', font: 'Helvetica' },
    mood: '극단적 미니멀, UI 없음', characteristics: ['텍스트만', '장식 제로', '최대 여백', '오직 내용'], texture: '없음', layoutGuide: '중앙 텍스트만, 아무것도 없음' },

  { id: 'one_color', name: '원 컬러', category: '심플', style: { bg: '#E8E8E8', text: '#4A4A4A', accent: '#4A4A4A', font: 'Inter' },
    mood: '단일 색상, 모노톤', characteristics: ['한 가지 색 농도 변화', '그림자로 구분', '색 통일', '차분함'], texture: '없음', layoutGuide: '명도 차이로만 구분' },

  // 모던 +2
  { id: 'metaverse', name: '메타버스', category: '모던', style: { bg: '#0A0A1A', text: '#FFFFFF', accent: '#A855F7', font: 'Space Grotesk' },
    mood: '메타버스, 가상현실', characteristics: ['3D 요소', '홀로그램', '그라데이션', 'VR 느낌'], texture: '디지털 그리드', layoutGuide: '플로팅 요소, 깊이감' },

  { id: 'ai_tech', name: 'AI 테크', category: '모던', style: { bg: '#0F172A', text: '#FFFFFF', accent: '#38BDF8', font: 'JetBrains Mono' },
    mood: 'AI, 머신러닝, 테크', characteristics: ['뉴럴 네트워크', '데이터 시각화', '미래적', '코드 요소'], texture: '회로 패턴', layoutGuide: '노드 연결 그래픽, 데이터 플로우' },

  // 비즈니스 +4
  { id: 'esg', name: 'ESG 리포트', category: '비즈니스', style: { bg: '#FFFFFF', text: '#1E3A5F', accent: '#22C55E', font: 'Pretendard' },
    mood: 'ESG 보고서, 지속가능경영', characteristics: ['환경 색상', '데이터 차트', '아이콘 활용', 'SDGs 요소'], texture: '없음', layoutGuide: 'E/S/G 섹션 구분, 지표 강조' },

  { id: 'brand_guide', name: '브랜드 가이드', category: '비즈니스', style: { bg: '#F8F8F8', text: '#1A1A1A', accent: '#FF5733', font: 'Helvetica Neue' },
    mood: '브랜드 가이드라인, CI 매뉴얼', characteristics: ['컬러 팔레트', '로고 규정', '타이포 가이드', '사용 예시'], texture: '없음', layoutGuide: '그리드 시스템, 규정 설명' },

  { id: 'ma', name: 'M&A', category: '비즈니스', style: { bg: '#0D1B2A', text: '#FFFFFF', accent: '#FFD700', font: 'Times New Roman' },
    mood: 'M&A, 인수합병 제안', characteristics: ['격식 있는 톤', '재무 데이터', '시너지 분석', '타임라인'], texture: '없음', layoutGuide: '거래 구조도, 밸류에이션 표' },

  { id: 'board', name: '이사회 보고', category: '비즈니스', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#1E40AF', font: 'Noto Sans KR' },
    mood: '이사회, 주주총회 자료', characteristics: ['공식 문서 느낌', '의결 안건', '재무제표', '경영 성과'], texture: '없음', layoutGuide: '안건별 구분, 숫자 강조' },

  // 내추럴 +2
  { id: 'camping', name: '캠핑', category: '내추럴', style: { bg: '#2C3E2D', text: '#F5F5DC', accent: '#FF6B35', font: 'Gowun Dodum' },
    mood: '캠핑, 아웃도어', characteristics: ['자연 색상', '캠프파이어', '장비 리스트', '코스 안내'], texture: '나무결 hint', layoutGuide: '체크리스트 구조, 아이콘 활용' },

  { id: 'farm', name: '농장', category: '내추럴', style: { bg: '#FDF6E3', text: '#5D4037', accent: '#8BC34A', font: 'Noto Serif KR' },
    mood: '농장, 팜투테이블, 유기농', characteristics: ['흙빛 색상', '작물 일러스트', '시즌 정보', '자연주의'], texture: '삼베 질감', layoutGuide: '계절별 구분, 제품 소개' },

  // 럭셔리 +2
  { id: 'yacht', name: '요트', category: '럭셔리', style: { bg: '#0C2340', text: '#FFFFFF', accent: '#C9A962', font: 'Didot' },
    mood: '요트, 해양 럭셔리', characteristics: ['네이비 블루', '골드 포인트', '항해 요소', 'VIP 느낌'], texture: '없음', layoutGuide: '선박 이미지, 스펙 정보' },

  { id: 'private_jet', name: '프라이빗 제트', category: '럭셔리', style: { bg: '#1A1A1A', text: '#FFFFFF', accent: '#D4AF37', font: 'Playfair Display' },
    mood: '프라이빗 제트, 최고급 서비스', characteristics: ['블랙 럭셔리', '금색 라인', '서비스 안내', 'VIP 전용'], texture: '카본 파이버 hint', layoutGuide: '인테리어 이미지, 서비스 목록' },

  // 레트로 +2
  { id: 'cassette', name: '카세트 테이프', category: '레트로', style: { bg: '#2D2D2D', text: '#FFFFFF', accent: '#FF6B6B', font: 'VT323' },
    mood: '카세트 테이프, 80년대 믹스테이프', characteristics: ['테이프 라벨', '손글씨', 'A/B면', '플레이리스트'], texture: '노이즈 그레인', layoutGuide: '카세트 형태 프레임' },

  { id: 'film_noir', name: '필름 느와르', category: '레트로', style: { bg: '#0D0D0D', text: '#FFFFFF', accent: '#8B0000', font: 'Playfair Display' },
    mood: '필름 느와르, 40년대 영화', characteristics: ['흑백 고대비', '그림자 강조', '미스터리', '빈티지 영화'], texture: '필름 그레인', layoutGuide: '대각선 그림자, 드라마틱' },

  // 크리에이티브 +2
  { id: 'ai_art', name: 'AI 아트', category: '크리에이티브', style: { bg: '#1A1A2E', text: '#FFFFFF', accent: '#E94560', font: 'Space Grotesk' },
    mood: 'AI 생성 아트, 제너레이티브', characteristics: ['디지털 아트', '글리치', '초현실', 'AI 생성 느낌'], texture: '노이즈 패턴', layoutGuide: '이미지 중심, 프롬프트 표시' },

  { id: 'generative', name: '제너레이티브', category: '크리에이티브', style: { bg: '#000000', text: '#FFFFFF', accent: '#00FF00', font: 'Roboto Mono' },
    mood: '제너레이티브 아트, 코드 아트', characteristics: ['알고리즘 패턴', '코드 요소', '무한 변형', '디지털 추상'], texture: '픽셀 패턴', layoutGuide: '패턴 배경, 코드 스니펫' },

  // 학술 +2
  { id: 'medical_journal', name: '의학 저널', category: '학술', style: { bg: '#FFFFFF', text: '#1A365D', accent: '#0077B6', font: 'Times New Roman' },
    mood: '의학 논문, 의료 저널', characteristics: ['2단 레이아웃', '그림/표 번호', '참고문헌', 'IMRAD 구조'], texture: '없음', layoutGuide: '논문 형식, 그림 캡션' },

  { id: 'patent', name: '특허 문서', category: '학술', style: { bg: '#FFFFF5', text: '#1A1A1A', accent: '#2F5496', font: 'Courier New' },
    mood: '특허 명세서, 기술 문서', characteristics: ['도면 설명', '청구항 구조', '번호 체계', '공식 문서'], texture: '없음', layoutGuide: '도면 중앙, 설명 하단' },

  // 카툰 +2
  { id: 'pixel_art', name: '픽셀 아트', category: '카툰', style: { bg: '#1A1A2E', text: '#FFFFFF', accent: '#FF6B6B', font: 'Press Start 2P' },
    mood: '픽셀 아트, 8비트 스타일', characteristics: ['픽셀 그래픽', '레트로 게임', '도트 폰트', '저해상도 느낌'], texture: '픽셀 그리드', layoutGuide: '큰 픽셀, 게임 UI 느낌' },

  { id: 'emoticon', name: '이모티콘', category: '카툰', style: { bg: '#FFEB3B', text: '#333333', accent: '#FF5722', font: 'Jua' },
    mood: '이모티콘, 카카오 스티커', characteristics: ['귀여운 캐릭터', '말풍선', '감정 표현', '심플한 선'], texture: '없음', layoutGuide: '캐릭터 중앙, 텍스트 최소' },

  // 테크니컬 +2
  { id: 'network', name: '네트워크 다이어그램', category: '테크니컬', style: { bg: '#F0F4F8', text: '#1A365D', accent: '#3182CE', font: 'Roboto' },
    mood: '네트워크 구성도, IT 인프라', characteristics: ['노드 연결', '아이콘 활용', '범례 표시', '흐름 화살표'], texture: '없음', layoutGuide: '중앙 서버, 연결선 표시' },

  { id: 'api_doc', name: 'API 문서', category: '테크니컬', style: { bg: '#1E1E1E', text: '#D4D4D4', accent: '#4EC9B0', font: 'Fira Code' },
    mood: 'API 문서, 개발자 문서', characteristics: ['코드 블록', '엔드포인트', '파라미터 표', '응답 예시'], texture: '없음', layoutGuide: 'Request/Response 구조' },

  // ========== 산업/제조 (8) ==========
  { id: 'factory', name: '공장 라인', category: '산업/제조', style: { bg: '#374151', text: '#F9FAFB', accent: '#FBBF24', font: 'Roboto' },
    mood: '제조공장, 생산라인', characteristics: ['산업용 노랑', '안전 표시', '공정도', '설비 이미지'], texture: '금속 질감', layoutGuide: '공정 흐름도, 수치 강조' },

  { id: 'logistics', name: '물류 창고', category: '산업/제조', style: { bg: '#1E3A5F', text: '#FFFFFF', accent: '#F97316', font: 'Inter' },
    mood: '물류센터, 유통창고', characteristics: ['박스 아이콘', '배송 트래킹', '재고 현황', '지도 연동'], texture: '없음', layoutGuide: '물류 흐름도, KPI 대시보드' },

  { id: 'automotive', name: '자동차', category: '산업/제조', style: { bg: '#0F0F0F', text: '#FFFFFF', accent: '#E11D48', font: 'Montserrat' },
    mood: '자동차 제조, 모터쇼', characteristics: ['다이내믹 라인', '스펙 표시', '3D 뷰', '프리미엄 느낌'], texture: '카본 파이버', layoutGuide: '차량 이미지 중심, 스펙 하단' },

  { id: 'semiconductor', name: '반도체', category: '산업/제조', style: { bg: '#0C1222', text: '#E0E7FF', accent: '#6366F1', font: 'Space Grotesk' },
    mood: '반도체, 칩 설계', characteristics: ['회로 패턴', '클린룸 이미지', '기술 스펙', '나노 스케일'], texture: '회로 패턴', layoutGuide: '칩 다이어그램, 공정 단계' },

  { id: 'shipbuilding', name: '조선', category: '산업/제조', style: { bg: '#0E4DA4', text: '#FFFFFF', accent: '#60A5FA', font: 'Roboto' },
    mood: '조선소, 선박 제조', characteristics: ['해양 블루', '선박 도면', '스케일 강조', '산업 느낌'], texture: '없음', layoutGuide: '선박 설계도, 사양 표' },

  { id: 'aerospace', name: '항공우주', category: '산업/제조', style: { bg: '#020617', text: '#FFFFFF', accent: '#38BDF8', font: 'Orbitron' },
    mood: 'NASA, SpaceX 스타일', characteristics: ['우주 배경', '기술 데이터', '미래적', '정밀 수치'], texture: '별 필드', layoutGuide: '로켓/위성 이미지, 미션 타임라인' },

  { id: 'energy_plant', name: '에너지 플랜트', category: '산업/제조', style: { bg: '#1F2937', text: '#F3F4F6', accent: '#10B981', font: 'Inter' },
    mood: '발전소, 에너지 설비', characteristics: ['전력 그래프', '설비 현황', '안전 지표', '효율 수치'], texture: '없음', layoutGuide: '발전량 대시보드, 설비 배치도' },

  { id: 'smart_factory', name: '스마트 팩토리', category: '산업/제조', style: { bg: '#111827', text: '#FFFFFF', accent: '#8B5CF6', font: 'JetBrains Mono' },
    mood: 'Industry 4.0, IoT 공장', characteristics: ['디지털 트윈', '센서 데이터', '자동화', 'AI 분석'], texture: '디지털 그리드', layoutGuide: '실시간 모니터링 UI' },

  // ========== 부동산/건축 (8) ==========
  { id: 'apartment', name: '아파트 분양', category: '부동산/건축', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#0EA5E9', font: 'Pretendard' },
    mood: '아파트 분양, 모델하우스', characteristics: ['평면도', '조감도', '세대 정보', '분양가'], texture: '없음', layoutGuide: '단지 조감도, 평형별 정보' },

  { id: 'interior', name: '인테리어', category: '부동산/건축', style: { bg: '#FAF5F0', text: '#44403C', accent: '#A16207', font: 'Cormorant' },
    mood: '인테리어 디자인, 홈스타일링', characteristics: ['무드보드', '자재 팔레트', '시공 사례', '비포애프터'], texture: '우드 질감', layoutGuide: '공간 사진 중심, 컨셉 설명' },

  { id: 'architecture', name: '건축 설계', category: '부동산/건축', style: { bg: '#F8FAFC', text: '#0F172A', accent: '#64748B', font: 'Helvetica Neue' },
    mood: '건축사무소, 설계 포트폴리오', characteristics: ['도면', '렌더링', '스케일바', '기술 스펙'], texture: '청사진 hint', layoutGuide: '입면도/단면도, 프로젝트 개요' },

  { id: 'landscape', name: '조경', category: '부동산/건축', style: { bg: '#ECFDF5', text: '#064E3B', accent: '#22C55E', font: 'Noto Sans KR' },
    mood: '조경 설계, 공원 디자인', characteristics: ['식재 계획', '조감도', '그린 톤', '자연 요소'], texture: '없음', layoutGuide: '배치도, 식물 리스트' },

  { id: 'commercial', name: '상업 시설', category: '부동산/건축', style: { bg: '#18181B', text: '#FFFFFF', accent: '#EAB308', font: 'Montserrat' },
    mood: '쇼핑몰, 상업용 건물', characteristics: ['임대 정보', '층별 안내', '유동인구', '수익률'], texture: '없음', layoutGuide: '층별 도면, 임대 조건표' },

  { id: 'office_building', name: '오피스 빌딩', category: '부동산/건축', style: { bg: '#F1F5F9', text: '#1E293B', accent: '#3B82F6', font: 'Inter' },
    mood: '오피스, 업무 시설', characteristics: ['전용면적', '공용시설', '교통 접근성', '빌딩 스펙'], texture: '없음', layoutGuide: '빌딩 외관, 층별 평면' },

  { id: 'remodeling', name: '리모델링', category: '부동산/건축', style: { bg: '#FFFBEB', text: '#78350F', accent: '#F59E0B', font: 'Noto Sans KR' },
    mood: '리모델링, 리노베이션', characteristics: ['비포애프터', '시공 과정', '예산표', '공사 일정'], texture: '없음', layoutGuide: '전후 비교, 공정표' },

  { id: 'model_house', name: '모델하우스', category: '부동산/건축', style: { bg: '#FFFFFF', text: '#1C1917', accent: '#A855F7', font: 'Playfair Display' },
    mood: '모델하우스, 프리미엄 분양', characteristics: ['럭셔리 인테리어', '마감재', 'VR 투어', '특화 설계'], texture: '대리석 hint', layoutGuide: '인테리어 갤러리, 특장점' },

  // ========== 법률/정치 (8) ==========
  { id: 'courtroom', name: '법정', category: '법률/정치', style: { bg: '#1C1917', text: '#FAFAF9', accent: '#B91C1C', font: 'Times New Roman' },
    mood: '법정, 재판 자료', characteristics: ['판례 인용', '법조문', '증거 자료', '격식체'], texture: '없음', layoutGuide: '조문 인용, 판결 요지' },

  { id: 'contract', name: '계약서', category: '법률/정치', style: { bg: '#FFFEF5', text: '#1F2937', accent: '#1E40AF', font: 'Noto Serif KR' },
    mood: '계약서, 법률 문서', characteristics: ['조항 번호', '서명란', '날인 위치', '정식 양식'], texture: '종이 질감', layoutGuide: '조항별 구분, 당사자 정보' },

  { id: 'election', name: '선거 캠페인', category: '법률/정치', style: { bg: '#1E3A8A', text: '#FFFFFF', accent: '#EF4444', font: 'Black Han Sans' },
    mood: '선거 캠페인, 정치 홍보', characteristics: ['후보 사진', '공약', '슬로건', '기호'], texture: '없음', layoutGuide: '후보 중심, 공약 리스트' },

  { id: 'policy', name: '정책 발표', category: '법률/정치', style: { bg: '#F8FAFC', text: '#0F172A', accent: '#0369A1', font: 'Pretendard' },
    mood: '정부 정책, 공공 발표', characteristics: ['공식 로고', '통계 자료', '추진 일정', '예산안'], texture: '없음', layoutGuide: '정책명 상단, 추진 로드맵' },

  { id: 'parliament', name: '국회', category: '법률/정치', style: { bg: '#0F172A', text: '#FFFFFF', accent: '#FBBF24', font: 'Noto Sans KR' },
    mood: '국회, 의회 자료', characteristics: ['의안 번호', '찬반 현황', '회의록', '공식 양식'], texture: '없음', layoutGuide: '의안 요약, 투표 결과' },

  { id: 'lawfirm', name: '로펌', category: '법률/정치', style: { bg: '#1C1917', text: '#F5F5F4', accent: '#D4AF37', font: 'Cormorant' },
    mood: '로펌 소개, 법률 서비스', characteristics: ['전문 분야', '변호사 프로필', '수임 사례', '권위적'], texture: '가죽 질감', layoutGuide: '파트너 소개, 전문 영역' },

  { id: 'regulation', name: '규제 안내', category: '법률/정치', style: { bg: '#FEF2F2', text: '#7F1D1D', accent: '#DC2626', font: 'Noto Sans KR' },
    mood: '규제, 컴플라이언스', characteristics: ['경고 표시', '체크리스트', '벌칙 안내', '준수사항'], texture: '없음', layoutGuide: '체크리스트, 위반 시 제재' },

  { id: 'ngo', name: '시민 단체', category: '법률/정치', style: { bg: '#ECFDF5', text: '#064E3B', accent: '#059669', font: 'Noto Sans KR' },
    mood: 'NGO, 시민단체', characteristics: ['캠페인', '서명운동', '활동 보고', '기부 안내'], texture: '없음', layoutGuide: '미션 상단, 활동 성과' },

  // ========== 패션/뷰티 (8) ==========
  { id: 'fashion_week', name: '패션위크', category: '패션/뷰티', style: { bg: '#000000', text: '#FFFFFF', accent: '#F472B6', font: 'Didot' },
    mood: '패션위크, 런웨이', characteristics: ['모델 사진', '컬렉션', '디자이너 정보', '시즌'], texture: '없음', layoutGuide: '룩 이미지 중심, 미니멀 텍스트' },

  { id: 'lookbook', name: '룩북', category: '패션/뷰티', style: { bg: '#FAFAFA', text: '#171717', accent: '#A3A3A3', font: 'Helvetica Neue' },
    mood: '룩북, 스타일 가이드', characteristics: ['코디 사진', '아이템 정보', '가격표', '컬러웨이'], texture: '없음', layoutGuide: '그리드 레이아웃, 제품 상세' },

  { id: 'cosmetics', name: '화장품', category: '패션/뷰티', style: { bg: '#FDF2F8', text: '#831843', accent: '#EC4899', font: 'Cormorant' },
    mood: '화장품, 스킨케어', characteristics: ['제품 샷', '성분표', '사용법', '텍스처'], texture: '글로시', layoutGuide: '제품 중심, 성분/효능 하단' },

  { id: 'hair_salon', name: '헤어 살롱', category: '패션/뷰티', style: { bg: '#18181B', text: '#FFFFFF', accent: '#A78BFA', font: 'Poppins' },
    mood: '헤어살롱, 미용실', characteristics: ['시술 사진', '가격표', '스타일리스트', '예약 안내'], texture: '없음', layoutGuide: '비포애프터, 메뉴판' },

  { id: 'jewelry_brand', name: '주얼리', category: '패션/뷰티', style: { bg: '#0C0C0C', text: '#FFFFFF', accent: '#D4AF37', font: 'Cinzel' },
    mood: '주얼리 브랜드, 보석', characteristics: ['제품 클로즈업', '소재 정보', '프리미엄 느낌', '반짝임'], texture: '벨벳', layoutGuide: '보석 이미지 중심, 골드 라인' },

  { id: 'streetwear', name: '스트리트 패션', category: '패션/뷰티', style: { bg: '#18181B', text: '#FFFFFF', accent: '#EF4444', font: 'Anton' },
    mood: '스트리트웨어, 힙합 패션', characteristics: ['그래피티', '볼드 타이포', '콜라보', '드롭 일정'], texture: '콘크리트', layoutGuide: '제품 대형, 드롭 날짜 강조' },

  { id: 'k_beauty', name: 'K-뷰티', category: '패션/뷰티', style: { bg: '#FFF1F2', text: '#881337', accent: '#FB7185', font: 'Pretendard' },
    mood: 'K-뷰티, 한국 화장품', characteristics: ['글로우 스킨', '트렌드', '성분 강조', '귀여운 패키지'], texture: '물방울', layoutGuide: '제품 플랫레이, 스텝별 사용법' },

  { id: 'perfume', name: '향수', category: '패션/뷰티', style: { bg: '#1C1917', text: '#FEFCE8', accent: '#A16207', font: 'Playfair Display' },
    mood: '향수, 프래그런스', characteristics: ['보틀 샷', '노트 설명', '무드 이미지', '럭셔리'], texture: '없음', layoutGuide: '향수병 중심, 탑-미들-베이스 노트' },

  // ========== 환경/ESG (8) ==========
  { id: 'carbon_neutral', name: '탄소 중립', category: '환경/ESG', style: { bg: '#022C22', text: '#ECFDF5', accent: '#10B981', font: 'Inter' },
    mood: '탄소중립, 넷제로', characteristics: ['탄소 배출량', '감축 목표', '그린 에너지', '타임라인'], texture: '없음', layoutGuide: '감축 그래프, 목표 연도' },

  { id: 'recycling', name: '재활용', category: '환경/ESG', style: { bg: '#F0FDF4', text: '#166534', accent: '#22C55E', font: 'Noto Sans KR' },
    mood: '재활용, 분리수거', characteristics: ['재활용 마크', '분리배출', '순환 경제', '아이콘'], texture: '없음', layoutGuide: '분리배출 안내, 순환 다이어그램' },

  { id: 'renewable', name: '신재생 에너지', category: '환경/ESG', style: { bg: '#0C4A6E', text: '#FFFFFF', accent: '#38BDF8', font: 'Montserrat' },
    mood: '태양광, 풍력, 신재생', characteristics: ['에너지원', '발전량', '설치 현황', '경제성'], texture: '없음', layoutGuide: '에너지 믹스 차트, 설비 사진' },

  { id: 'climate', name: '기후 변화', category: '환경/ESG', style: { bg: '#1E3A8A', text: '#FFFFFF', accent: '#F97316', font: 'Roboto' },
    mood: '기후변화, 환경 캠페인', characteristics: ['온도 그래프', '해수면', '빙하', '경고 메시지'], texture: '없음', layoutGuide: '데이터 시각화, 임팩트 수치' },

  { id: 'eco_packaging', name: '친환경 포장', category: '환경/ESG', style: { bg: '#FEF3C7', text: '#78350F', accent: '#65A30D', font: 'Noto Sans KR' },
    mood: '친환경 포장, 지속가능', characteristics: ['생분해', '재활용 소재', '인증마크', '비교표'], texture: '크래프트 종이', layoutGuide: '소재 비교, 인증 마크' },

  { id: 'sustainability', name: '지속 가능', category: '환경/ESG', style: { bg: '#FFFFFF', text: '#064E3B', accent: '#059669', font: 'Inter' },
    mood: 'SDGs, 지속가능경영', characteristics: ['SDGs 아이콘', '성과 지표', '이해관계자', 'ESG 등급'], texture: '없음', layoutGuide: 'SDGs 연계, KPI 대시보드' },

  { id: 'green_tech', name: '그린 테크', category: '환경/ESG', style: { bg: '#0F172A', text: '#F0FDF4', accent: '#4ADE80', font: 'Space Grotesk' },
    mood: '친환경 기술, 클린테크', characteristics: ['혁신 기술', '투자 현황', '특허', '미래 전망'], texture: '디지털 그리드', layoutGuide: '기술 로드맵, 투자 유치' },

  { id: 'ocean_protect', name: '해양 보호', category: '환경/ESG', style: { bg: '#0369A1', text: '#FFFFFF', accent: '#06B6D4', font: 'Montserrat' },
    mood: '해양보호, 플라스틱 프리', characteristics: ['해양 생물', '오염 현황', '보호 활동', '캠페인'], texture: '물결 패턴', layoutGuide: '바다 이미지, 캠페인 메시지' },

  // ========== 펫/동물 (8) ==========
  { id: 'pet_care', name: '반려동물', category: '펫/동물', style: { bg: '#FFF7ED', text: '#7C2D12', accent: '#F97316', font: 'Nunito' },
    mood: '반려동물, 펫 케어', characteristics: ['귀여운 사진', '돌봄 팁', '건강 정보', '친근한 톤'], texture: '없음', layoutGuide: '펫 사진 중심, 정보 카드' },

  { id: 'vet_clinic', name: '동물 병원', category: '펫/동물', style: { bg: '#F0FDFA', text: '#134E4A', accent: '#14B8A6', font: 'Noto Sans KR' },
    mood: '동물병원, 수의과', characteristics: ['진료 안내', '수술 정보', '예방접종', '의료 아이콘'], texture: '없음', layoutGuide: '진료 과목, 의료진 소개' },

  { id: 'pet_shop', name: '펫샵', category: '펫/동물', style: { bg: '#FFFBEB', text: '#78350F', accent: '#FBBF24', font: 'Varela Round' },
    mood: '펫샵, 반려용품', characteristics: ['제품 사진', '가격표', '카테고리', '프로모션'], texture: '없음', layoutGuide: '상품 그리드, 할인 배너' },

  { id: 'animal_shelter', name: '동물 보호', category: '펫/동물', style: { bg: '#FDF2F8', text: '#831843', accent: '#EC4899', font: 'Noto Sans KR' },
    mood: '유기동물, 입양 캠페인', characteristics: ['입양 안내', '보호 동물', '후원 방법', '감성적'], texture: '없음', layoutGuide: '동물 프로필, 입양 절차' },

  { id: 'wildlife', name: '야생 동물', category: '펫/동물', style: { bg: '#14532D', text: '#FFFFFF', accent: '#A3E635', font: 'Merriweather' },
    mood: '야생동물, 다큐멘터리', characteristics: ['자연 사진', '서식지', '보존 현황', '내셔널지오그래픽'], texture: '없음', layoutGuide: '풀스크린 동물 사진, 정보 오버레이' },

  { id: 'aquarium', name: '아쿠아리움', category: '펫/동물', style: { bg: '#0C4A6E', text: '#E0F2FE', accent: '#38BDF8', font: 'Poppins' },
    mood: '수족관, 해양생물', characteristics: ['바다 생물', '전시 안내', '체험 프로그램', '블루 톤'], texture: '물방울', layoutGuide: '생물 갤러리, 관람 동선' },

  { id: 'farm_animal', name: '농장 동물', category: '펫/동물', style: { bg: '#FEF3C7', text: '#78350F', accent: '#D97706', font: 'Gowun Dodum' },
    mood: '농장, 목축업', characteristics: ['농장 풍경', '사육 정보', '생산품', '자연주의'], texture: '건초 질감', layoutGuide: '농장 사진, 동물별 정보' },

  { id: 'pet_food', name: '펫 푸드', category: '펫/동물', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#059669', font: 'Inter' },
    mood: '반려동물 사료, 간식', characteristics: ['영양 성분', '급여 가이드', '원재료', '제품 라인'], texture: '없음', layoutGuide: '제품 샷, 영양 성분표' },

  // ========== 기존 카테고리 보강 ==========
  // 비즈니스 +6
  { id: 'franchise', name: '프랜차이즈', category: '비즈니스', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#DC2626', font: 'Pretendard' },
    mood: '프랜차이즈 사업설명회', characteristics: ['가맹 조건', '수익 모델', '지원 사항', '성공 사례'], texture: '없음', layoutGuide: '가맹 조건표, 매출 그래프' },

  { id: 'small_biz', name: '스몰 비즈니스', category: '비즈니스', style: { bg: '#FEF3C7', text: '#78350F', accent: '#F59E0B', font: 'Noto Sans KR' },
    mood: '소상공인, 창업', characteristics: ['따뜻한 톤', '스토리텔링', '수제/로컬', '친근한 느낌'], texture: '크래프트 종이', layoutGuide: '창업 스토리, 제품 소개' },

  { id: 'supply_chain', name: '공급망', category: '비즈니스', style: { bg: '#1E3A5F', text: '#FFFFFF', accent: '#22D3EE', font: 'Roboto' },
    mood: 'SCM, 공급망 관리', characteristics: ['흐름도', '파트너 맵', '재고 현황', '리드타임'], texture: '없음', layoutGuide: '공급망 다이어그램, KPI' },

  { id: 'agile', name: '애자일', category: '비즈니스', style: { bg: '#F3E8FF', text: '#581C87', accent: '#A855F7', font: 'Inter' },
    mood: '애자일, 스크럼', characteristics: ['스프린트 보드', '번다운 차트', '칸반', '스탠드업'], texture: '없음', layoutGuide: '스프린트 현황, 백로그' },

  { id: 'okr', name: 'OKR', category: '비즈니스', style: { bg: '#FFFFFF', text: '#0F172A', accent: '#2563EB', font: 'Inter' },
    mood: 'OKR, 목표 관리', characteristics: ['목표/핵심결과', '진척도', '분기별 리뷰', '정렬'], texture: '없음', layoutGuide: 'Objective 상단, Key Results 하단' },

  { id: 'quarterly', name: '분기 보고', category: '비즈니스', style: { bg: '#F8FAFC', text: '#1E293B', accent: '#0EA5E9', font: 'Pretendard' },
    mood: '분기 보고서, QBR', characteristics: ['실적 요약', '차트', 'YoY 비교', '주요 이슈'], texture: '없음', layoutGuide: '핵심 지표 상단, 상세 하단' },

  // 강의교안 +6
  { id: 'stem', name: 'STEM 교육', category: '강의교안', style: { bg: '#0F172A', text: '#F8FAFC', accent: '#22D3EE', font: 'Space Grotesk' },
    mood: '과학/기술/공학/수학', characteristics: ['실험 이미지', '공식', '다이어그램', '실습 가이드'], texture: '회로 패턴', layoutGuide: '개념 설명, 실험 단계' },

  { id: 'language', name: '언어 학습', category: '강의교안', style: { bg: '#EFF6FF', text: '#1E40AF', accent: '#3B82F6', font: 'Noto Sans KR' },
    mood: '영어/외국어 학습', characteristics: ['단어 카드', '예문', '발음 기호', '퀴즈'], texture: '없음', layoutGuide: '단어-뜻-예문 구조' },

  { id: 'history_class', name: '역사 수업', category: '강의교안', style: { bg: '#FEF3C7', text: '#78350F', accent: '#B45309', font: 'Noto Serif KR' },
    mood: '역사 수업, 사회', characteristics: ['연대표', '지도', '인물 사진', '사료'], texture: '오래된 종이', layoutGuide: '타임라인, 역사 지도' },

  { id: 'art_class', name: '미술 수업', category: '강의교안', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#EC4899', font: 'Playfair Display' },
    mood: '미술 교육, 창작', characteristics: ['작품 예시', '기법 설명', '재료', '실습 단계'], texture: '캔버스 질감', layoutGuide: '작품 갤러리, 기법 설명' },

  { id: 'music_class', name: '음악 수업', category: '강의교안', style: { bg: '#1C1917', text: '#FAFAF9', accent: '#FBBF24', font: 'Noto Sans KR' },
    mood: '음악 교육, 악기', characteristics: ['악보', '음표', '악기 이미지', '연습 포인트'], texture: '없음', layoutGuide: '악보 영역, 연주 팁' },

  { id: 'pe_class', name: '체육 수업', category: '강의교안', style: { bg: '#DCFCE7', text: '#166534', accent: '#22C55E', font: 'Roboto' },
    mood: '체육, 스포츠 교육', characteristics: ['동작 설명', '규칙', '준비운동', '경기 방법'], texture: '없음', layoutGuide: '동작 이미지, 규칙 설명' },

  // 소셜미디어 +4
  { id: 'threads', name: '스레드', category: '소셜미디어', style: { bg: '#000000', text: '#FFFFFF', accent: '#FFFFFF', font: 'SF Pro Display' },
    mood: '스레드, 텍스트 SNS', characteristics: ['짧은 텍스트', '미니멀', '대화형', '스레드 연결'], texture: '없음', layoutGuide: '텍스트 중심, 심플' },

  { id: 'behance', name: '비핸스', category: '소셜미디어', style: { bg: '#0057FF', text: '#FFFFFF', accent: '#FFFFFF', font: 'Helvetica Neue' },
    mood: '비핸스 포트폴리오', characteristics: ['프로젝트 케이스', '목업', '프로세스', '크리에이티브'], texture: '없음', layoutGuide: '프로젝트 썸네일, 상세 과정' },

  { id: 'dribbble', name: '드리블', category: '소셜미디어', style: { bg: '#F9F5F1', text: '#1F2937', accent: '#EA4C89', font: 'Inter' },
    mood: '드리블, 디자인 샷', characteristics: ['샷 형식', 'UI/UX', '일러스트', '디자인 쇼케이스'], texture: '없음', layoutGuide: '작업물 중심, 핑크 포인트' },

  { id: 'notion_style', name: '노션 스타일', category: '소셜미디어', style: { bg: '#FFFFFF', text: '#37352F', accent: '#EB5757', font: 'Inter' },
    mood: '노션 템플릿, 문서', characteristics: ['블록 구조', '토글', '체크박스', '이모지 아이콘'], texture: '없음', layoutGuide: '노션 블록 스타일, 심플' },

  // 이벤트 +4
  { id: 'launch_party', name: '런칭 파티', category: '이벤트', style: { bg: '#0F0F0F', text: '#FFFFFF', accent: '#F472B6', font: 'Montserrat' },
    mood: '제품 런칭, 론칭 이벤트', characteristics: ['카운트다운', '제품 공개', '파티 분위기', '네온'], texture: '없음', layoutGuide: '제품 중심, 런칭 날짜' },

  { id: 'awards', name: '시상식', category: '이벤트', style: { bg: '#1C1917', text: '#FFFFFF', accent: '#D4AF37', font: 'Playfair Display' },
    mood: '시상식, 어워드', characteristics: ['트로피', '수상자', '격식', '골드 포인트'], texture: '벨벳', layoutGuide: '수상 부문, 수상자 프로필' },

  { id: 'expo', name: '박람회', category: '이벤트', style: { bg: '#1E3A8A', text: '#FFFFFF', accent: '#FBBF24', font: 'Roboto' },
    mood: '전시회, 박람회', characteristics: ['부스 배치', '일정표', '참가사', '등록 안내'], texture: '없음', layoutGuide: '플로어맵, 프로그램 일정' },

  { id: 'popup', name: '팝업 스토어', category: '이벤트', style: { bg: '#FDF4FF', text: '#701A75', accent: '#D946EF', font: 'Poppins' },
    mood: '팝업스토어, 한정 이벤트', characteristics: ['한정판', '포토존', '굿즈', '트렌디'], texture: '없음', layoutGuide: '이벤트 내용, 위치/기간' },

  // 여행 +4
  { id: 'cruise', name: '크루즈', category: '여행', style: { bg: '#0C4A6E', text: '#FFFFFF', accent: '#F8FAFC', font: 'Playfair Display' },
    mood: '크루즈 여행, 선상', characteristics: ['선박 정보', '기항지', '객실 등급', '럭셔리'], texture: '없음', layoutGuide: '항로 지도, 일정표' },

  { id: 'backpacking', name: '백패킹', category: '여행', style: { bg: '#365314', text: '#FFFFFF', accent: '#BEF264', font: 'Gowun Dodum' },
    mood: '배낭여행, 트레킹', characteristics: ['코스 지도', '준비물', '날씨', '팁'], texture: '없음', layoutGuide: '루트 맵, 체크리스트' },

  { id: 'glamping', name: '글램핑', category: '여행', style: { bg: '#FEF3C7', text: '#78350F', accent: '#D97706', font: 'Cormorant' },
    mood: '글램핑, 감성 캠핑', characteristics: ['텐트 인테리어', '액티비티', '예약 안내', '자연'], texture: '린넨 질감', layoutGuide: '시설 사진, 프로그램' },

  { id: 'themepark', name: '테마파크', category: '여행', style: { bg: '#7C3AED', text: '#FFFFFF', accent: '#FDE047', font: 'Jua' },
    mood: '놀이공원, 테마파크', characteristics: ['어트랙션', '지도', '이벤트', '즐거움'], texture: '없음', layoutGuide: '파크맵, 추천 코스' },

  // 음식 +4
  { id: 'bakery', name: '베이커리', category: '음식', style: { bg: '#FEF3C7', text: '#78350F', accent: '#D97706', font: 'Playfair Display' },
    mood: '베이커리, 빵집', characteristics: ['빵 사진', '재료', '굽는 과정', '따뜻한 톤'], texture: '밀가루 텍스처', layoutGuide: '제품 갤러리, 가격표' },

  { id: 'bar', name: '바/칵테일', category: '음식', style: { bg: '#1C1917', text: '#FAFAF9', accent: '#F97316', font: 'Bebas Neue' },
    mood: '바, 칵테일 바', characteristics: ['칵테일 사진', '레시피', '분위기', '메뉴판'], texture: '없음', layoutGuide: '시그니처 칵테일, 메뉴' },

  { id: 'vegan', name: '비건', category: '음식', style: { bg: '#ECFDF5', text: '#064E3B', accent: '#10B981', font: 'Noto Sans KR' },
    mood: '비건, 채식', characteristics: ['식물성', '영양정보', '레시피', '친환경'], texture: '없음', layoutGuide: '재료 사진, 영양 성분' },

  { id: 'mealkit', name: '밀키트', category: '음식', style: { bg: '#FFFFFF', text: '#1F2937', accent: '#EF4444', font: 'Pretendard' },
    mood: '밀키트, 간편식', characteristics: ['구성품', '조리법', '시간', '칼로리'], texture: '없음', layoutGuide: '패키지 샷, 조리 단계' },

  // 건강/웰빙 +4
  { id: 'pilates', name: '필라테스', category: '건강/웰빙', style: { bg: '#F5F3FF', text: '#5B21B6', accent: '#8B5CF6', font: 'Cormorant' },
    mood: '필라테스 스튜디오', characteristics: ['동작 사진', '프로그램', '강사 소개', '우아함'], texture: '없음', layoutGuide: '동작 시퀀스, 클래스 안내' },

  { id: 'oriental', name: '한의원', category: '건강/웰빙', style: { bg: '#FEF3C7', text: '#78350F', accent: '#92400E', font: 'Noto Serif KR' },
    mood: '한의원, 한방', characteristics: ['전통', '침/뜸', '한약', '자연 치료'], texture: '한지', layoutGuide: '진료 과목, 한의사 소개' },

  { id: 'dental', name: '치과', category: '건강/웰빙', style: { bg: '#F0F9FF', text: '#0C4A6E', accent: '#0EA5E9', font: 'Noto Sans KR' },
    mood: '치과, 구강 건강', characteristics: ['치아 이미지', '시술 안내', '전후 비교', '청결'], texture: '없음', layoutGuide: '시술 과정, 가격 안내' },

  { id: 'eye_clinic', name: '안과', category: '건강/웰빙', style: { bg: '#FFFFFF', text: '#1E3A8A', accent: '#3B82F6', font: 'Inter' },
    mood: '안과, 시력 교정', characteristics: ['눈 이미지', '검사 안내', '수술 정보', '의료적'], texture: '없음', layoutGuide: '검사 항목, 의료진 소개' },

  // 스포츠 +4
  { id: 'swimming', name: '수영', category: '스포츠', style: { bg: '#0891B2', text: '#FFFFFF', accent: '#FFFFFF', font: 'Montserrat' },
    mood: '수영, 수영장', characteristics: ['레인', '기록', '자세', '물결'], texture: '물결 패턴', layoutGuide: '수영 동작, 기록표' },

  { id: 'tennis', name: '테니스', category: '스포츠', style: { bg: '#166534', text: '#FFFFFF', accent: '#FBBF24', font: 'Roboto' },
    mood: '테니스, 라켓 스포츠', characteristics: ['코트', '스코어', '장비', '경기'], texture: '잔디', layoutGuide: '코트 다이어그램, 경기 일정' },

  { id: 'skiing', name: '스키', category: '스포츠', style: { bg: '#1E3A8A', text: '#FFFFFF', accent: '#38BDF8', font: 'Oswald' },
    mood: '스키, 겨울 스포츠', characteristics: ['슬로프', '장비', '리조트', '눈'], texture: '눈 텍스처', layoutGuide: '슬로프 지도, 난이도' },

  { id: 'martial_arts', name: '격투기', category: '스포츠', style: { bg: '#0F0F0F', text: '#FFFFFF', accent: '#EF4444', font: 'Anton' },
    mood: '격투기, 무술', characteristics: ['파이터', '대진표', '체급', '강렬함'], texture: '없음', layoutGuide: '대진표, 선수 프로필' },

  // 뮤직/공연 +4
  { id: 'hiphop', name: '힙합', category: '뮤직/공연', style: { bg: '#0F0F0F', text: '#FFFFFF', accent: '#FBBF24', font: 'Anton' },
    mood: '힙합, 래퍼', characteristics: ['그래피티', '골드 체인', '비트', '스트릿'], texture: '그런지', layoutGuide: '아티스트 중심, 앨범 정보' },

  { id: 'indie', name: '인디 밴드', category: '뮤직/공연', style: { bg: '#FDF6E3', text: '#44403C', accent: '#EA580C', font: 'Caveat' },
    mood: '인디밴드, 언더그라운드', characteristics: ['손글씨', '아날로그', '공연 포스터', '감성적'], texture: '빈티지 종이', layoutGuide: '공연 정보, 밴드 사진' },

  { id: 'classical', name: '클래식', category: '뮤직/공연', style: { bg: '#1C1917', text: '#FAFAF9', accent: '#D4AF37', font: 'Cormorant' },
    mood: '클래식 음악, 교향악', characteristics: ['악기', '지휘자', '프로그램', '격식'], texture: '벨벳', layoutGuide: '곡목, 연주자 프로필' },

  { id: 'gugak', name: '국악', category: '뮤직/공연', style: { bg: '#FEF3C7', text: '#78350F', accent: '#B91C1C', font: 'Noto Serif KR' },
    mood: '국악, 전통음악', characteristics: ['전통 악기', '한복', '궁중', '민속'], texture: '한지', layoutGuide: '공연 정보, 전통 문양' },

  // 크리에이티브 +4
  { id: 'hologram', name: '홀로그램', category: '크리에이티브', style: { bg: '#0F0F0F', text: '#FFFFFF', accent: '#E879F9', font: 'Space Grotesk' },
    mood: '홀로그램, 미래 디스플레이', characteristics: ['무지개빛', '투명', '3D 효과', '미래적'], texture: '홀로그램 패턴', layoutGuide: '홀로그램 이미지, 스펙' },

  { id: '3d_render', name: '3D 렌더링', category: '크리에이티브', style: { bg: '#1A1A2E', text: '#FFFFFF', accent: '#6366F1', font: 'Sora' },
    mood: '3D 아트, 렌더링', characteristics: ['3D 오브젝트', '조명', '질감', '시네마틱'], texture: '없음', layoutGuide: '렌더 이미지 중심, 정보 최소화' },

  { id: 'motion', name: '모션 그래픽', category: '크리에이티브', style: { bg: '#18181B', text: '#FFFFFF', accent: '#F97316', font: 'Inter' },
    mood: '모션그래픽, 애니메이션', characteristics: ['프레임', '타임라인', '이징', '다이내믹'], texture: '없음', layoutGuide: '키프레임 시퀀스, 프로젝트 정보' },

  { id: 'ar_vr', name: 'AR/VR', category: '크리에이티브', style: { bg: '#0F172A', text: '#FFFFFF', accent: '#8B5CF6', font: 'Orbitron' },
    mood: 'AR, VR, XR', characteristics: ['헤드셋', '가상공간', '인터랙션', '미래적'], texture: '디지털 그리드', layoutGuide: '디바이스 이미지, 기술 설명' },

  // 테크니컬 +4
  { id: 'datacenter', name: '데이터센터', category: '테크니컬', style: { bg: '#0F172A', text: '#E2E8F0', accent: '#22D3EE', font: 'JetBrains Mono' },
    mood: '데이터센터, 서버실', characteristics: ['서버 랙', '쿨링', '전력', '가동률'], texture: '없음', layoutGuide: '인프라 구성도, 성능 지표' },

  { id: 'cloud', name: '클라우드', category: '테크니컬', style: { bg: '#1E40AF', text: '#FFFFFF', accent: '#38BDF8', font: 'Inter' },
    mood: 'AWS/Azure/GCP 클라우드', characteristics: ['클라우드 아키텍처', '서비스', '비용', '확장성'], texture: '없음', layoutGuide: '아키텍처 다이어그램, 가격표' },

  { id: 'cybersecurity', name: '사이버 보안', category: '테크니컬', style: { bg: '#0D0D0D', text: '#22C55E', accent: '#EF4444', font: 'Fira Code' },
    mood: '보안, 해킹 방어', characteristics: ['방화벽', '암호화', '위협 탐지', '터미널'], texture: '매트릭스', layoutGuide: '보안 구조, 위협 대응' },

  { id: 'iot', name: 'IoT', category: '테크니컬', style: { bg: '#F0FDF4', text: '#064E3B', accent: '#10B981', font: 'Roboto' },
    mood: 'IoT, 사물인터넷', characteristics: ['센서', '연결', '스마트홈', '디바이스'], texture: '없음', layoutGuide: '디바이스 연결도, 데이터 흐름' },

  // 종교 +2
  { id: 'buddhist', name: '불교', category: '종교', style: { bg: '#FEF3C7', text: '#78350F', accent: '#92400E', font: 'Noto Serif KR' },
    mood: '불교, 사찰', characteristics: ['연꽃', '불상', '명상', '고요함'], texture: '한지 질감', layoutGuide: '부처님 이미지, 경전 인용' },

  { id: 'islamic', name: '이슬람', category: '종교', style: { bg: '#064E3B', text: '#ECFDF5', accent: '#D4AF37', font: 'Noto Sans Arabic' },
    mood: '이슬람, 모스크', characteristics: ['아라베스크', '초승달', '기하학 패턴', '경건함'], texture: '아라베스크 패턴', layoutGuide: '기하학 문양, 경전 인용' },
];

const CATEGORIES = ['전체', '심플', '모던', '비즈니스', '내추럴', '럭셔리', '레트로', '크리에이티브', '학술', '카툰', '테크니컬', '크래프트', '재미', '강의교안', '종교', '소셜미디어', '이벤트', '여행', '음식', '스포츠', '건강/웰빙', '키즈', '포토', '뮤직/공연', '산업/제조', '부동산/건축', '법률/정치', '패션/뷰티', '환경/ESG', '펫/동물'];
