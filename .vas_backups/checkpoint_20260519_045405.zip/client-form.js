/* =========================================
   client-form.js
   폼 네비게이션, 드래그앤드롭, 완료 화면, 다국어 전환 로직
   (자동저장 제거 — 매번 새 폼으로 시작)
   ========================================= */

let currentLang = 'ko';
let cur = 1;
const total = 5;

/* 언어 전환 */
function setLang(lang) {
    currentLang = lang;
    document.getElementById('btn-ko').classList.toggle('active', lang === 'ko');
    document.getElementById('btn-en').classList.toggle('active', lang === 'en');

    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (i18n[lang][key]) el.innerHTML = i18n[lang][key];
    });

    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
        const key = el.getAttribute('data-i18n-ph');
        if (i18n[lang][key]) el.setAttribute('placeholder', i18n[lang][key]);
    });

    updateUI();
}

/* 진행 상태 UI 갱신 */
function updateUI() {
    document.getElementById('progressText').innerHTML = `0${cur}<span>/0${total}</span>`;

    const prevBtn = document.getElementById('prevBtn');
    prevBtn.style.opacity = cur === 1 ? '0' : '1';
    prevBtn.style.pointerEvents = cur === 1 ? 'none' : 'auto';

    const nextBtn = document.getElementById('nextBtn');
    if (cur === total) {
        nextBtn.innerHTML = i18n[currentLang]['btnSubmit'];
        nextBtn.classList.add('finish');
    } else {
        nextBtn.innerHTML = i18n[currentLang]['btnNext'];
        nextBtn.classList.remove('finish');
    }
}

/* 스텝 이동 */
function changeStep(dir) {
    const steps = document.querySelectorAll('.step');

    if (dir === 1) {
        const currentStepEl = document.querySelector(`[data-step="${cur}"]`);
        const inputs = currentStepEl.querySelectorAll('input[required], textarea[required]');
        for (let input of inputs) {
            if (!input.checkValidity()) {
                input.reportValidity();
                return;
            }
        }
    }

    cur += dir;
    if (cur < 1) cur = 1;
    if (cur > total) { showDone(); return; }

    steps.forEach(s => {
        s.style.opacity = '0';
        s.style.transform = 'translateY(40px)';
        setTimeout(() => s.classList.remove('active'), 300);
    });

    setTimeout(() => {
        const nextStep = document.querySelector(`[data-step="${cur}"]`);
        nextStep.classList.add('active');
        void nextStep.offsetWidth;
        nextStep.style.opacity = '1';
        nextStep.style.transform = 'translateY(0)';
        const firstInput = nextStep.querySelector('input, textarea');
        if (firstInput) firstInput.focus();
    }, 350);

    updateUI();
}

/* 완료 화면 진입 */
function showDone() {
    document.querySelector('.step.active').style.display = 'none';
    document.getElementById('navWrap').style.display = 'none';
    const ds = document.getElementById('doneScreen');
    ds.classList.add('active');
}

/* 완료 화면 → 폼으로 복귀 */
function goBackFromDone() {
    document.getElementById('doneScreen').classList.remove('active');
    document.getElementById('navWrap').style.display = 'flex';
    cur = total;
    const lastStep = document.querySelector(`.step[data-step="${total}"]`);
    lastStep.classList.add('active');
    setTimeout(() => {
        lastStep.style.display = 'block';
        lastStep.style.opacity = '1';
        lastStep.style.transform = 'translateY(0)';
        updateUI();
    }, 50);
}

/* 새로 작성하기 — 페이지 리로드로 초기화 */
function clearForm() {
    const msg = currentLang === 'ko'
        ? '작성 중인 내용을 모두 지우고 처음부터 다시 시작하시겠습니까?'
        : 'Clear all and start over?';
    if (confirm(msg)) location.reload();
}

/* 드래그 앤 드롭 로직 */
const dropZone = document.getElementById('dropZone');
const fileChips = document.getElementById('fileChips');
let uploadedFiles = [];

dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
});
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
});

function handleFiles(files) {
    for (let f of files) uploadedFiles.push(f.name);
    renderFiles();
}
function removeFile(index, event) {
    event.stopPropagation();
    uploadedFiles.splice(index, 1);
    renderFiles();
}
function renderFiles() {
    fileChips.innerHTML = '';
    uploadedFiles.forEach((name, i) => {
        const chip = document.createElement('div');
        chip.className = 'file-chip';
        chip.innerHTML = `📄 ${name} <button type="button" onclick="removeFile(${i}, event)">×</button>`;
        fileChips.appendChild(chip);
    });
    let hidden = document.getElementById('hiddenFiles');
    if (!hidden) {
        hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = 'attached_files';
        hidden.id = 'hiddenFiles';
        document.getElementById('projectForm').appendChild(hidden);
    }
    hidden.value = JSON.stringify(uploadedFiles);
}

/* 초기 렌더링 */
setTimeout(() => {
    const firstStep = document.querySelector('.step.active');
    if (firstStep) {
        firstStep.style.opacity = '1';
        firstStep.style.transform = 'translateY(0)';
    }
}, 100);
updateUI();
setLang(currentLang);
