# 템플릿 버전 마이그레이션 가이드

이 문서는 **에이전트 팀 템플릿**의 버전 업그레이드 시 기존 프로젝트에 변경 사항을 적용하는 방법을 안내합니다.

---

## 마이그레이션 원칙

1. **GEMINI.md, INSTRUCTIONS.md** — 프로젝트별 내용이 포함되므로 **수동 머지** 필요
2. **SKILL.md (6개)** — YAML 프론트매터 변경 시 **주의하여 갱신** (프로젝트별 커스터마이즈 영역 보존)
3. **워크플로우 (.md)** — 프로젝트 독립적이므로 **직접 교체** 가능
4. **스크립트 (.sh/.ps1)** — 프로젝트별 커스터마이즈가 있으면 **수동 머지**, 없으면 교체
5. **access-control.md, advisor-strategy.md** — 프로젝트별 정책이 있으면 수동 머지

---

## 버전별 마이그레이션 절차

### v2.0 → v2.1

| 파일 | 액션 | 설명 |
|------|------|------|
| 5개 SKILL.md | YAML 수정 | `read_file` → 삭제, ABAC 자가 진단 섹션 추가 |
| dev-cycle.md | 교체 | 경량 모드, 반려 포맷, 롤백 절차 추가 |
| hotfix.md | 교체 | 반려 포맷 추가 |
| setup-from-application.md | 교체 | Step 4.5 스캐폴딩, Step 6 검증 추가 |
| GEMINI.md | 수동 머지 | "현재 진행 상태" + "충돌 규칙" 섹션 추가 |
| INSTRUCTIONS.md | 수동 머지 | 섹션 5.1/5.2/7/8 추가 |
| .ps1 스크립트 4개 | 신규 복사 | Windows 호환 스크립트 |
| src/README.md, tests/README.md | 신규 복사 | 스캐폴딩 |
| .gitignore | 신규 복사 | |

### v2.1 → v2.2

| 파일 | 액션 | 설명 |
|------|------|------|
| dev-cycle.md | 교체 | 각 Step에 진입 조건 + LESSONS 기록 안내 추가 |
| hotfix.md | 교체 | 진입 조건 + LESSONS 기록 안내 추가 |
| ultra-plan.md | 교체 | GEMINI 시작/종료 + LESSONS 기록 안내 추가 |
| setup-from-application.md | 교체 | GEMINI 종료 + LESSONS 스캐폴딩 + 참조 문서 갱신 |
| dep-update.md | 신규 복사 | 의존성 업데이트 워크플로우 |
| CUSTOM_GUIDE.md | 신규 복사 | 커스텀 워크플로우 작성 가이드 |
| LESSONS.md | 신규 복사 | 교훈 축적 시스템 |
| MIGRATION.md | 신규 복사 | 이 파일 (마이그레이션 가이드) |
| INSTRUCTIONS.md | 수동 머지 | 섹션 9(코드 소유권), 10(GEMINI 최적화), 11(멀티프로젝트) |
| GEMINI.md | 수동 머지 | 참조 문서에 LESSONS/MIGRATION 추가, RBAC에 LESSONS 추가 |
| access-control.md | 수동 머지 | Security RBAC에 LESSONS.md 쓰기 추가 |
| Security SKILL.md | YAML 수정 | `allowed_write_paths`에 LESSONS.md 추가 |
| .agents/hooks/ | 신규 복사 | Git 훅 템플릿 |
| .agents/ci/ | 신규 복사 | CI/CD 템플릿 |

### v2.2 → v2.3

| 파일 | 액션 | 설명 |
|------|------|------|
| `.agents/skills/designer/SKILL.md` | **신규 복사** | Designer 에이전트 스킬 (Claude Design 기반) |
| `.agents/skills/designer/references/README.md` | **신규 복사** | Claude Design 활용 가이드, Figma 연동 패턴 |
| `src/assets/README.md` | **신규 복사** | Designer 작업 공간 안내 |
| `access-control.md` | **수동 머지** | RBAC 테이블에 Designer 행, ABAC target에 designer 추가 |
| `dev-cycle.md` | **교체** | Step 1.5 Designer 삽입, 디자인 반려 포맷, 유기적 상호 검증 |
| `hotfix.md` | **수동 머지** | Designer 생략 명시 |
| `setup-from-application.md` | **교체** | 3-10 Designer 스킬 생성, Step 4 리소스 테이블, 파일 수 10개 |
| `GEMINI.md` | **수동 머지** | RBAC 요약 테이블에 Designer 행 추가 |
| `INSTRUCTIONS.md` | **수동 머지** | 코드 소유권, 폴더 구조, 라이프사이클, 커밋 메시지에 Designer 반영 |
| `README.md` | **교체** | 전체 시스템 가이드로 재작성 (에이전트 역할, 워크플로우, 접근 제어 등) |
| Architect SKILL.md | **수동 머지** | 인계 대상을 Designer(UI 변경 시) 또는 Implementer로 변경 |
| Implementer SKILL.md | **수동 머지** | 작업 완료 기준에 디자인 명세 준수 체크 추가 |
| Reviewer SKILL.md | **수동 머지** | 디자인 명세 일치 검토 항목 추가 |
| `reviewer/references/checklist.md` | **수동 머지** | 디자인 명세 검토 섹션 추가 |
| `advisor-strategy.md` | **수동 머지** | Designer Advisor 시나리오 추가 |
| `mcp_config_template.json` | **수동 머지** | Figma MCP 서버 설정 예시 추가 |
| `src/README.md` | **수동 머지** | Designer `src/assets/` 쓰기 권한, 구조에 assets/ 추가 |
| `LESSONS.md` | **수동 머지** | `#디자인` 태그 추가 |
| `HISTORY.md` | **이력 추가** | v2.3 변경 이력 + 후속 보완 이력 |
| `MIGRATION.md` | **이력 추가** | 이 섹션 (v2.2→v2.3 절차) |

---

## 마이그레이션 체크리스트

프로젝트에 새 템플릿 버전을 적용할 때 아래를 순서대로 확인합니다:

- [ ] 새 버전의 MIGRATION.md에서 해당 버전 섹션 확인
- [ ] "교체" 파일은 새 템플릿에서 직접 복사
- [ ] "수동 머지" 파일은 diff 비교 후 프로젝트 고유 내용 보존하며 새 섹션 추가
- [ ] "신규 복사" 파일은 새 템플릿에서 복사 후 프로젝트에 맞게 커스터마이즈
- [ ] HISTORY.md에 마이그레이션 이력 기록
- [ ] 전체 워크플로우 참조 경로가 정상인지 확인

---

## 향후 버전 추가 시

이 파일의 "버전별 마이그레이션 절차" 섹션에 새 항목을 추가합니다.
형식: `### vX.Y → vX.Z` + 파일별 액션 테이블
