# 프로젝트 연대기 및 교훈 (Log & Lessons)

이 문서는 에이전트 시스템이 스스로 유지보수하는 **작업 이력 및 교훈 기록장**입니다.
작업(`/dev-cycle` 또는 `/migration-cycle`)이 완료되어 `final/` 폴더로 코드가 병합될 때마다, Security 에이전트가 가장 최상단에 새로운 내역과 교훈을 덧붙입니다.

---

## 2026-05-19 프로젝트 무결성 감사 — 3건 이슈 처리

- **분류:** `[유지보수]`
- **수행 내용:**
  1. **백업 파일명 오타 수정:** `.vas_backups/checkpoint_202605d042622.zip` → `checkpoint_20260519_042622.zip` (날짜 포맷 정규화).
  2. **`final/` 디렉토리 동기화 (15개 파일):** 루트에서 완료된 작업물이 `final/`에 미반영되어 있던 것을 일괄 복사. HTML 3개, JS 4개, CSS 4개(신규 9 + 업데이트 2) + MD 4개(GEMINI/HANDOFF/INSTRUCTIONS/README) 동기화 및 바이트 단위 검증 통과.
  3. **`design-controller.html` 크기 불일치 해결:** 루트(24.8KB)가 final(18.0KB)보다 컸던 것은 디자인 정합성 복구 및 프리셋 폰트 스택 교정 작업이 final에 미반영된 것이 원인. #2에서 함께 해결됨.
- **교훈/특이사항:**
  - **final/ 동기화 누락 패턴:** 여러 세션에 걸쳐 루트에서 작업 후 Security 단계에서 final 반영을 누락한 케이스. `/dev-cycle` 종료 시 Security 에이전트의 final 동기화 체크리스트를 더 엄격히 적용할 것.

---

## 2026-05-19 코드 품질 감사 + 3건 조치 + 10-Loop 무결점 검증 (86/86 PASS)

- **분류:** `[품질 감사 및 리팩터링]`
- **수행 내용:**
  1. **`client-application.html` 인라인 스크립트 제거:** `client-application-init.js`와 100% 중복이던 인라인 `<script>` 블록(~100줄) 삭제. 외부 JS 참조로 교체 (512줄 -> 202줄).
  2. **`client-style.css` 924줄 -> 3파일 분리:** `client-style.css`(399줄) + `client-components.css`(68줄, 드래그존/파일칩/버튼) + `client-print.css`(18줄, 인쇄모드). CSS @import 체인으로 연결.
  3. **`README.md` 구버전 참조 정리:** `HISTORY.md`/`LESSONS.md` 잔존 참조 6건을 `docs/log.md`로 통일.
  4. **`test_integrity_10loop.py` 작성 및 실행:** 10가지 카테고리(HTML 구문, CSS 체인, JS 참조, 500줄 규칙, 데드 파일, i18n 정합성, 프리셋 12종, final/ 무결성, 폰트 폴백, 크로스 레퍼런스) 총 86건 검증 항목 → **86/86 = 100% PASS**.
- **교훈/특이사항:**
  - **`replace_file_content`로 한국어 HTML 수정 시 파일 손상 위험:** 이번에도 multi-byte 문자 포함 HTML을 replace하다 파일이 198줄로 절단됨. 반드시 **Python `open(..., encoding='utf-8')`로 전체 덮어쓰기** 사용.
  - **CSS @import로 500줄 분리 시 주의:** `@import url()`은 반드시 CSS 파일 최상단(다른 규칙 앞)에 위치해야 한다. CDN import 뒤에 로컬 import를 놓는 것은 OK.

---

## ⚠️ 에이전트 행동 금지사항 (2026-05-19 등록 — 반드시 숙지)

> 사용자가 같은 말을 두 번 하지 않도록, 다음 규칙을 작업 전 반드시 체크한다.

### 파일 조작
- **PowerShell `Set-Content`로 한국어 파일 절대 금지.** `\r\n` 이중 개행 + 인코딩 혼합으로 한글 깨짐. 반드시 **Python `open(..., encoding='utf-8')`** 사용.
- **색상 교체 시 파일 범위 명확히 지정.** `index.html`과 `client-application.html`은 별개 디자인 시스템. 스크립트마다 파일 경로 명시.
- **파일 추가 전 루트 디렉토리 존재 여부 확인 필수.** `final/`에만 있는 파일을 허브에 링크하면 404.

### 디자인 변경
- **허브(`index.html`) 디자인은 사용자 확정 상태. 임의 변경 금지.**
  - 카드 모서리: `border-radius: 0` 각진 형태 유지
  - 카드 텍스트: 기울어진 채 시작 → 호버 시 펴지는 애니메이션 유지
  - 카드 배경색: design=yellow, prompt=blue 고정
- **CSS 우선순위 점검 필수.** 구체적인 선택자(`.card-canvas.prompt .graphic`)가 있으면 일반 호버 규칙이 묻힌다. `transform` 계열은 항상 호버 전용 규칙도 함께 추가.
- **TASTE-RULES 색상 변경은 해당 폼(`client-application.html`)에만 적용.** 다른 HTML로 전파 금지.
- **사용자 승인 없이 추천 기능을 임의 구현 금지.**

### 워크플로우 및 컨텍스트 압축 (Log Condensation)
- **`final/`에 있는 파일은 사용자 확인 없이 루트 복사 금지.** Final-Centric: `final/` 분리는 의도적.
- **허브 카드 추가/삭제는 명시적 요청에만.** 감사 리포트 '권장'은 구현 승인이 아님.
- **로그 자동 압축 (Log Condensation):** Security 에이전트는 작업을 마칠 때마다 이전 로그(교훈) 중 중복되거나 오래된 내용을 3~4줄 이내로 핵심만 요약 병합(Merge)하여 토큰 낭비를 막아야 한다.

---

## 2026-05-19 Auto-Orchestrator 도입 및 10-Loop 무결점 검증

- **분류:** `[인프라 업데이트]`
- **수행 내용:**
  - AI 스스로 `[인계]` 바통을 이어받아 다음 에이전트 역할을 자동 수행하는 `[⚡ Auto-Orchestrator Protocol]`을 `GEMINI.md`와 `/setup-from-application` 스캐폴드 템플릿에 주입.
  - 단위 테스트 프레임워크가 없는 경량 프론트엔드 작업 시, 에이전트가 억지 코드를 생성하다 오류를 내지 않도록 `Tester` 단계를 건너뛰는 `[💡 Tester Bypass (경량 룰)]` 도입.
  - Python 시뮬레이터를 통해 10가지 각기 다른 프로젝트 상황(백엔드/프론트/보안)을 주입한 풀오토(Full-Auto) 릴레이 시뮬레이션을 10전 10승 무결점(10/10)으로 통과.
- **교훈/특이사항:**
  - 진정한 바이브 코딩 파이프라인(Full-Auto)은 사용자가 "다음 단계 진행해"라고 라우팅해주는 것을 넘어서, AI 스스로 프로젝트 성격을 인지하고 분기(Routing)를 타는 "지능형 오케스트레이션"이 필수적임.

---

## 2026-05-19 디자인 정합성 복구 및 TASTE-RULES 강제화

- **분류:** `[디자인 QA 및 버그 픽스]`
- **수행 내용:**
  - `Pretendard` 폰트 CDN 에러(구글 폰트 미등록)를 `jsDelivr` 공식 정적 링크로 전면 교체하여 폰트 깨짐 현상 완벽 해결.
  - `Neo-Brutalism` 테마의 `Geist Mono` 폰트가 한글을 미지원하여 영문/한글 타이포그래피가 언밸런스하게 렌더링되던 이슈 해결 (`index.html`과 `client-application.html` 렌더링 엔진에 `Pretendard` 자동 폴백 JS 백신 주입).
  - `client-application.html`의 'NEXT STEP'과 'SUBMIT' 버튼 디자인이 파편화되어 있던 것을 통일 (하드코딩된 `.btn-next.finish` 삭제).
  - `index.html` 허브 카드의 `SYSTEM CORE` 타이포그래피에 삭제되었던 `<br>` 복구 및 TASTE-RULES의 **[Anti-Center Bias]** 를 적용하여 좌측 하단 앵커링(-8deg 비대칭)으로 거친 브루탈리즘 느낌 극대화.
- **교훈/특이사항:**
  - **폰트 폴백(Fallback)의 위험성:** 한글을 지원하지 않는 코딩용 폰트(`Geist Mono` 등)를 프리셋 메인 폰트로 지정할 경우, 브라우저가 임의로 가장 못생긴 폰트로 한글을 대체해버린다. TASTE-RULES에 명시된 대로 **항상 한글(Pretendard)을 최우선 폴백으로 보장**해야 한다.
  - **테마 프리셋 맹신 금지:** 프리셋을 만들더라도 항상 엣지 케이스(다국어 지원 등)를 고려한 JS 자동 교정 로직이 뷰 레이어에 동반되어야 한다.

---

## 2026-05-19 client-application.html 대규모 UX 수술 + 시스템 전체 보완

- **분류:** `[UX 핫픽스 + 인프라 보완]`
- **수행 내용:**
  - DONE 화면 백 버튼(`goBackFromDone()`) 신설 — 마지막 스텝으로 정확히 복귀
  - 완료 버튼(PDF/JSON/Email) 호버(Hover) 색반전 브루탈리즘 마이크로 애니메이션 적용
  - 선택 블록(Checked) 시각 버그 수정 — `--accent`/`--text-main` CSS 변수 충돌로 전체 블랙아웃되던 현상 해결. `var(--text-main)`/`var(--bg-color)` 강제 교차 반전으로 모든 테마에서 가시성 확보
  - Live Server 핫리로드 JS Null Reference 크래시 방어 — `cur > total` 상태에서 `loadForm()` 호출 시 발생하던 스크립트 전사 버그, 예외 처리(`if (cur > total)`) 추가
  - `↺ 새로 작성하기` 버튼 신설 (`clearForm()`) — localStorage 자동 저장으로 체크박스가 영구히 박혀있는 문제 해결
  - `final/HISTORY.md`, `final/LESSONS.md` 좀비 파일 삭제 — `docs/log.md` SSoT 원칙 강화
  - `index.html` 허브에 `slide-styles.html`, `session-monitor.html` 카드 추가
  - `client-application.html` 1157줄 → JS 3개 파일 분리 (500줄 규칙 준수)
  - CDN 오프라인 감지 + 경고 UI 추가
  - `tests/test_client_form.py` 신규 함수 테스트 추가
- **교훈/특이사항:**
  - **localStorage + Live Reload 충돌:** 폼 자동 저장으로 DONE 상태(step=6)가 저장된 상태에서 Live Server가 HTML을 리로드하면, 존재하지 않는 6번째 스텝을 찾다가 JS가 전사한다. `if (cur > total)` 조건 분기 필수.
  - **CSS 변수 충돌 패턴:** 테마 컬러를 동적으로 주입할 때 `background`와 `color`를 항상 쌍으로 반전 처리해야 한다. 한 쪽만 바꾸면 보호색이 된다.
  - **초기화(Clear) 기능은 자동 저장 기능의 필수 짝꿍:** 자동 저장을 구현하면 반드시 초기화 버튼도 함께 제공해야 한다.

---

## 2026-05-18 LLM Wiki 아키텍처 통합

- **분류:** `[인프라 업데이트]`
- **수행 내용:** 
  - 파편화되어 있던 `HISTORY.md`와 `LESSONS.md`를 `docs/log.md`로 통합.
  - 에이전트가 작업을 시작할 때 `docs/index.md`를 읽어 프로젝트 현황을 파악하도록 `INSTRUCTIONS.md` 개편.
  - `/dev-cycle` 및 `/migration-cycle` 종료 시, 별도의 명령어 없이 유기적으로(Automatically) Security 에이전트가 이 `docs/log.md`를 업데이트하도록 체크리스트 강제화.
- **교훈/특이사항:** 너무 많은 명시적 룰(명령어)은 에이전트의 워크플로우를 망가뜨림. 룰은 최소화하고 기존 사이클(시작과 끝)에 자동화된 톱니바퀴처럼 물리게 하는 것이 가장 효율적임.

---

## 2026-05-18 전체 에이전트 품질 점검 및 보완

- **분류:** `[dev-cycle 보완]`
- **수행 내용:** 
  - `dashboard.html`에서 세션 건강도 로직을 `session-health.js`로 분리하여 500줄 제한 대비 파일 크기 최적화 (408줄 → 330줄). `slide-styles-data.js`의 963줄은 순수 데이터로 확인되어 예외 인정.
  - `tests/test_html_syntax.py` 스모크 테스트 스크립트 작성 및 100% 통과 확인. XSS 및 API 키 노출 점검 이상 없음.
- **교훈/특이사항:** 
  - **순수 데이터 500줄 예외:** `slide-styles-data.js`같이 순수 배열 데이터만 있는 경우 500줄 제한에서 예외 처리. (`-data.js` 접미사 사용)
  - **Python \U 이스케이프가 JavaScript에서 미지원:** 브라우저에서 이모지 대신 텍스트 그대로 나옴. JS에서는 반드시 `\u{XXXXX}` 형태나 실제 유니코드 이모지 문자 직접 사용 필수.

---

## 2026-05-18 VAS 2.4 마이그레이션 및 AI 코딩 가이드라인 통합

- **분류:** `[버전업 및 컨텍스트 강화]`
- **수행 내용:** 
  - **Andrej Karpathy 4대 코딩 원칙 통합:** `INSTRUCTIONS.md`에 Think Before Coding, Simplicity First, Surgical Changes, Goal-Driven Execution 추가.
  - `README.md`, `index.html`, `session-monitor.html`, `GEMINI.md` 등 프로젝트 전반의 버전 표기를 2.4로 상향.

---

## 2026-05-17 Phase 1 완료 — HTML 레이어 전체 구축

- **분류:** `[dev-cycle Phase 1]`
- **수행 내용:** 
  - `Run-VAS.bat` (Python HTTP 서버 로컬 구동 스크립트) 신설.
  - `index.html`, `dashboard.html`, `history.html`, `design-controller.html`, `guide.html`, `slide-styles.html` 6개의 허브 페이지 및 도구 구축.
  - 색상 시스템 `--primary: #6366f1`, 폰트 `Pretendard`, 다크 모드 통일.
- **교훈/특이사항:**
  - **NAS/WebDAV CORS 오류:** WebDAV 경로에서 실행 시 fetch() 타임아웃/CORS 오류 발생. 프로젝트를 로컬(C드라이브)로 복사해서 실행해야 함 (`guide.html`에 문서화 완료).
  - **multi_replace 파일 손상:** 특수문자(`&amp;` 등)가 포함된 HTML 라인을 변경하려다가 파일 전체가 70줄로 절단됨. HTML 수정 시엔 웬만하면 전체 덮어쓰기(Overwrite:true) 권장.
